{
  "$GMScript":"v1",
  "%Name":"restartuj_pokoj",
  "isCompatibility":false,
  "isDnD":false,
  "name":"restartuj_pokoj",
  "parent":{
    "name":"Pokoje",
    "path":"folders/Polskie skrypty/Pokoje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}