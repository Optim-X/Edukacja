{
  "$GMScript":"v1",
  "%Name":"przycisk_myszy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"przycisk_myszy",
  "parent":{
    "name":"Mysz",
    "path":"folders/Polskie skrypty/Mysz.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}