{
  "$GMScript":"v1",
  "%Name":"rozmiar_bufora",
  "isCompatibility":false,
  "isDnD":false,
  "name":"rozmiar_bufora",
  "parent":{
    "name":"Bufory",
    "path":"folders/Polskie skrypty/Bufory.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}