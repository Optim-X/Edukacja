{
  "$GMScript":"v1",
  "%Name":"rysuj_fragment_sprite",
  "isCompatibility":false,
  "isDnD":false,
  "name":"rysuj_fragment_sprite",
  "parent":{
    "name":"Rysowanie",
    "path":"folders/Polskie skrypty/Rysowanie.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}