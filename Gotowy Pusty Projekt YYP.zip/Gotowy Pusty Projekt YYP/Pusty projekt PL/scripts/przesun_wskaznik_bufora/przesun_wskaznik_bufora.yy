{
  "$GMScript":"v1",
  "%Name":"przesun_wskaznik_bufora",
  "isCompatibility":false,
  "isDnD":false,
  "name":"przesun_wskaznik_bufora",
  "parent":{
    "name":"Bufory",
    "path":"folders/Polskie skrypty/Bufory.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}