{
  "$GMScript":"v1",
  "%Name":"rozmiar_mapy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"rozmiar_mapy",
  "parent":{
    "name":"DS",
    "path":"folders/Polskie skrypty/DS.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}