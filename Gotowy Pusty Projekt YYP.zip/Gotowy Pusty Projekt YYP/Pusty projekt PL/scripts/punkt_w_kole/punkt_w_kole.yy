{
  "$GMScript":"v1",
  "%Name":"punkt_w_kole",
  "isCompatibility":false,
  "isDnD":false,
  "name":"punkt_w_kole",
  "parent":{
    "name":"Kolizje",
    "path":"folders/Polskie skrypty/Kolizje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}