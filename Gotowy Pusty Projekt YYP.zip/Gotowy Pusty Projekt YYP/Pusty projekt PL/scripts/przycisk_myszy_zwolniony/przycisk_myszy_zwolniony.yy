{
  "$GMScript":"v1",
  "%Name":"przycisk_myszy_zwolniony",
  "isCompatibility":false,
  "isDnD":false,
  "name":"przycisk_myszy_zwolniony",
  "parent":{
    "name":"Mysz",
    "path":"folders/Polskie skrypty/Mysz.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}