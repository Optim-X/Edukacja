{
  "$GMScript":"v1",
  "%Name":"pozycja_instancji",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pozycja_instancji",
  "parent":{
    "name":"Instancje",
    "path":"folders/Polskie skrypty/Instancje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}