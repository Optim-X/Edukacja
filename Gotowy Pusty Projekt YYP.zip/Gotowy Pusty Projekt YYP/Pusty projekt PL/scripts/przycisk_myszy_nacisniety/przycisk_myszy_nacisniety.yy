{
  "$GMScript":"v1",
  "%Name":"przycisk_myszy_nacisniety",
  "isCompatibility":false,
  "isDnD":false,
  "name":"przycisk_myszy_nacisniety",
  "parent":{
    "name":"Mysz",
    "path":"folders/Polskie skrypty/Mysz.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}