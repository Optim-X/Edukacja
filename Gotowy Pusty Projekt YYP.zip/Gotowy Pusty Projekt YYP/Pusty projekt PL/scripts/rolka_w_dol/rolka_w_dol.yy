{
  "$GMScript":"v1",
  "%Name":"rolka_w_dol",
  "isCompatibility":false,
  "isDnD":false,
  "name":"rolka_w_dol",
  "parent":{
    "name":"Mysz",
    "path":"folders/Polskie skrypty/Mysz.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}