{
  "$GMScript":"v1",
  "%Name":"rolka_w_gore",
  "isCompatibility":false,
  "isDnD":false,
  "name":"rolka_w_gore",
  "parent":{
    "name":"Mysz",
    "path":"folders/Polskie skrypty/Mysz.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}