{
  "$GMScript":"v1",
  "%Name":"rysuj_kolo",
  "isCompatibility":false,
  "isDnD":false,
  "name":"rysuj_kolo",
  "parent":{
    "name":"Rysowanie",
    "path":"folders/Polskie skrypty/Rysowanie.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}