{
  "$GMScript":"v1",
  "%Name":"pozycja_w_buforze",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pozycja_w_buforze",
  "parent":{
    "name":"Bufory",
    "path":"folders/Polskie skrypty/Bufory.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}