{
  "$GMScript":"v1",
  "%Name":"rozmiar_listy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"rozmiar_listy",
  "parent":{
    "name":"DS",
    "path":"folders/Polskie skrypty/DS.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}