{
  "$GMScript":"v1",
  "%Name":"rysuj_elipse",
  "isCompatibility":false,
  "isDnD":false,
  "name":"rysuj_elipse",
  "parent":{
    "name":"Rysowanie",
    "path":"folders/Polskie skrypty/Rysowanie.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}