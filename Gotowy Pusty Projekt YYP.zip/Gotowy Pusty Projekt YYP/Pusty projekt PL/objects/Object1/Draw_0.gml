ustaw_kolor(kolor_czerwony)
rysuj_okrag(x,y,10,0)