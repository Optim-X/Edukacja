jesli klawisz_wcisniety(klawisz_lewo) x-=5
jesli klawisz_wcisniety(klawisz_prawo) x+=5
jesli klawisz_wcisniety(klawisz_gora) y-=5
jesli klawisz_wcisniety(klawisz_dol) y+=5

jesli animacja=1 {czas1-- grafika++}
jesli czas1<0 {animacja=0 czas1=50 grafika=0}