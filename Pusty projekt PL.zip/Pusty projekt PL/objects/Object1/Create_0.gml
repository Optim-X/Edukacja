animacja=0 //jesli = 1 animacja jest widoczna
czas1=50 //czas animacji
grafika=0 //numer wyswietlanej grafiki