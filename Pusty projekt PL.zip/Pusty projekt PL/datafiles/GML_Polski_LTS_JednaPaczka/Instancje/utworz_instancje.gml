/// @function utworz_instancje(x,y,layer,obj)
/// @description Tworzy instancję na warstwie.
/// @param {any} x, y, layer, obj Parametry zgodne z funkcją instance_create_layer.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// utworz_instancje(x, y, layer, obj);
/// @see instance_create_layer

function utworz_instancje(_x, _y, _layer, _obj)
{
    return instance_create_layer(_x, _y, _layer, _obj);
}
