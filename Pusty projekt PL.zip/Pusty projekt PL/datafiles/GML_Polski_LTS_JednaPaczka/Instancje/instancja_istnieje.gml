/// @function instancja_istnieje(id)
/// @description Sprawdza istnienie.
/// @param {any} id Parametry zgodne z funkcją instance_exists.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// instancja_istnieje(id);
/// @see instance_exists

function instancja_istnieje(_id)
{
    return instance_exists(_id);
}
