/// @function najblizsza_instancja(x,y,obj)
/// @description Najbliższa instancja.
/// @param {any} x, y, obj Parametry zgodne z funkcją instance_nearest.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// najblizsza_instancja(x, y, obj);
/// @see instance_nearest

function najblizsza_instancja(_x, _y, _obj)
{
    return instance_nearest(_x, _y, _obj);
}
