/// @function najdalsza_instancja(x,y,obj)
/// @description Najdalsza instancja.
/// @param {any} x, y, obj Parametry zgodne z funkcją instance_furthest.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// najdalsza_instancja(x, y, obj);
/// @see instance_furthest

function najdalsza_instancja(_x, _y, _obj)
{
    return instance_furthest(_x, _y, _obj);
}
