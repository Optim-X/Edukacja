/// @function usun_instancje(id)
/// @description Usuwa instancję.
/// @param {any} id Parametry zgodne z funkcją instance_destroy.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_instancje(id);
/// @see instance_destroy

function usun_instancje(_id)
{
    return instance_destroy(_id);
}
