/// @function zmien_obiekt_instancji(obj,perform_events)
/// @description Zmienia obiekt.
/// @param {any} obj, perform_events Parametry zgodne z funkcją instance_change.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zmien_obiekt_instancji(obj, perform_events);
/// @see instance_change

function zmien_obiekt_instancji(_obj, _perform_events)
{
    return instance_change(_obj, _perform_events);
}
