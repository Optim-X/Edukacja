/// @function znajdz_instancje(obj,n)
/// @description Znajduje instancję.
/// @param {any} obj, n Parametry zgodne z funkcją instance_find.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// znajdz_instancje(obj, n);
/// @see instance_find

function znajdz_instancje(_obj, _n)
{
    return instance_find(_obj, _n);
}
