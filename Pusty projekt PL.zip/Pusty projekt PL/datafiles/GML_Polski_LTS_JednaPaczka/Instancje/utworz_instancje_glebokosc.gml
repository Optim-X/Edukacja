/// @function utworz_instancje_glebokosc(x,y,depth,obj)
/// @description Tworzy instancję na głębokości.
/// @param {any} x, y, depth, obj Parametry zgodne z funkcją instance_create_depth.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// utworz_instancje_glebokosc(x, y, depth, obj);
/// @see instance_create_depth

function utworz_instancje_glebokosc(_x, _y, _depth, _obj)
{
    return instance_create_depth(_x, _y, _depth, _obj);
}
