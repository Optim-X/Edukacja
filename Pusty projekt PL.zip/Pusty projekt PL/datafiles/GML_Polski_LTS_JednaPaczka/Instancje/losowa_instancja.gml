/// @function losowa_instancja(obiekt)
/// @description Zwraca losową instancję.
/// @param {any} _obiekt Parametr funkcji.
/// @returns {any} Wartość zwracana przez oryginalną funkcję, jeśli ją posiada.
/// @example
/// losowa_instancja(obiekt);
function losowa_instancja(_obiekt)
{
    return instance_random(_obiekt);
}
