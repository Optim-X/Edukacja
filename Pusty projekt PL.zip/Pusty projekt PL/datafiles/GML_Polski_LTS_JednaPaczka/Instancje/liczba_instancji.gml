/// @function liczba_instancji(obj)
/// @description Liczba instancji obiektu.
/// @param {any} obj Parametry zgodne z funkcją instance_number.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// liczba_instancji(obj);
/// @see instance_number

function liczba_instancji(_obj)
{
    return instance_number(_obj);
}
