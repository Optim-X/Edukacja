/// @function pozycja_instancji(x, y, obiekt)
/// @description Zwraca instancję w pozycji.
/// @param {any} _x, _y, _obiekt Parametr funkcji.
/// @returns {any} Wartość zwracana przez oryginalną funkcję, jeśli ją posiada.
/// @example
/// pozycja_instancji(x, y, obiekt);
function pozycja_instancji(_x, _y, _obiekt)
{
    return instance_position(_x, _y, _obiekt);
}
