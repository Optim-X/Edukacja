/// @function tekst(value)
/// @description Konwertuje wartość na tekst.
/// @param {any} value Parametry zgodne z funkcją string.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// tekst(value);
/// @see string

function tekst(_value)
{
    return string(_value);
}
