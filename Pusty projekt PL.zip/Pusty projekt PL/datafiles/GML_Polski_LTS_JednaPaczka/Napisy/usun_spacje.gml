/// @function usun_spacje(str)
/// @description Usuwa białe znaki.
/// @param {any} str Parametry zgodne z funkcją string_trim.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_spacje(str);
/// @see string_trim

function usun_spacje(_str)
{
    return string_trim(_str);
}
