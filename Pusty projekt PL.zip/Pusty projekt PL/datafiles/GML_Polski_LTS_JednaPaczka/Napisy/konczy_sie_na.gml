/// @function konczy_sie_na(str,substr)
/// @description Sprawdza koniec.
/// @param {any} str, substr Parametry zgodne z funkcją string_ends_with.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// konczy_sie_na(str, substr);
/// @see string_ends_with

function konczy_sie_na(_str, _substr)
{
    return string_ends_with(_str, _substr);
}
