/// @function kopiuj_napis(str,index,count)
/// @description Kopiuje fragment.
/// @param {any} str, index, count Parametry zgodne z funkcją string_copy.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// kopiuj_napis(str, index, count);
/// @see string_copy

function kopiuj_napis(_str, _index, _count)
{
    return string_copy(_str, _index, _count);
}
