/// @function polacz_napisy(array,delimiter)
/// @description Łączy tablicę tekstów.
/// @param {any} array, delimiter Parametry zgodne z funkcją string_join.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// polacz_napisy(array, delimiter);
/// @see string_join

function polacz_napisy(_array, _delimiter)
{
    return string_join(_array, _delimiter);
}
