/// @function tylko_cyfry(str)
/// @description Zwraca cyfry.
/// @param {any} str Parametry zgodne z funkcją string_digits.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// tylko_cyfry(str);
/// @see string_digits

function tylko_cyfry(_str)
{
    return string_digits(_str);
}
