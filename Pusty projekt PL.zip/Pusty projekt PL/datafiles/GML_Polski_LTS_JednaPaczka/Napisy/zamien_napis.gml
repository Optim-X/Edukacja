/// @function zamien_napis(str,substr,newstr)
/// @description Zamienia pierwsze wystąpienie.
/// @param {any} str, substr, newstr Parametry zgodne z funkcją string_replace.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zamien_napis(str, substr, newstr);
/// @see string_replace

function zamien_napis(_str, _substr, _newstr)
{
    return string_replace(_str, _substr, _newstr);
}
