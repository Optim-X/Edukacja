/// @function ostatnia_pozycja_napisu(substr,str)
/// @description Znajduje ostatnie wystąpienie.
/// @param {any} substr, str Parametry zgodne z funkcją string_last_pos.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ostatnia_pozycja_napisu(substr, str);
/// @see string_last_pos

function ostatnia_pozycja_napisu(_substr, _str)
{
    return string_last_pos(_substr, _str);
}
