/// @function tylko_litery(str)
/// @description Zwraca litery.
/// @param {any} str Parametry zgodne z funkcją string_letters.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// tylko_litery(str);
/// @see string_letters

function tylko_litery(_str)
{
    return string_letters(_str);
}
