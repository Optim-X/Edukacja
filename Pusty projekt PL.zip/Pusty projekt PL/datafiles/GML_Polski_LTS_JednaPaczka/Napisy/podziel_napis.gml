/// @function podziel_napis(str,delimiter)
/// @description Dzieli tekst na tablicę.
/// @param {any} str, delimiter Parametry zgodne z funkcją string_split.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// podziel_napis(str, delimiter);
/// @see string_split

function podziel_napis(_str, _delimiter)
{
    return string_split(_str, _delimiter);
}
