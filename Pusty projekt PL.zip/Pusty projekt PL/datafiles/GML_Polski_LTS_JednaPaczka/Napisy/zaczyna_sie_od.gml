/// @function zaczyna_sie_od(str,substr)
/// @description Sprawdza początek.
/// @param {any} str, substr Parametry zgodne z funkcją string_starts_with.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zaczyna_sie_od(str, substr);
/// @see string_starts_with

function zaczyna_sie_od(_str, _substr)
{
    return string_starts_with(_str, _substr);
}
