/// @function powtorz_napis(str,count)
/// @description Powtarza tekst.
/// @param {any} str, count Parametry zgodne z funkcją string_repeat.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// powtorz_napis(str, count);
/// @see string_repeat

function powtorz_napis(_str, _count)
{
    return string_repeat(_str, _count);
}
