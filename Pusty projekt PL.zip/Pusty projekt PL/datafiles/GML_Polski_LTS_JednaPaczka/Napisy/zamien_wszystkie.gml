/// @function zamien_wszystkie(str,substr,newstr)
/// @description Zamienia wszystkie wystąpienia.
/// @param {any} str, substr, newstr Parametry zgodne z funkcją string_replace_all.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zamien_wszystkie(str, substr, newstr);
/// @see string_replace_all

function zamien_wszystkie(_str, _substr, _newstr)
{
    return string_replace_all(_str, _substr, _newstr);
}
