/// @function znak_z_kodu(code)
/// @description Zwraca znak.
/// @param {any} code Parametry zgodne z funkcją chr.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// znak_z_kodu(code);
/// @see chr

function znak_z_kodu(_code)
{
    return chr(_code);
}
