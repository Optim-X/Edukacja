/// @function policz_wystapienia(substr,str)
/// @description Liczy wystąpienia.
/// @param {any} substr, str Parametry zgodne z funkcją string_count.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// policz_wystapienia(substr, str);
/// @see string_count

function policz_wystapienia(_substr, _str)
{
    return string_count(_substr, _str);
}
