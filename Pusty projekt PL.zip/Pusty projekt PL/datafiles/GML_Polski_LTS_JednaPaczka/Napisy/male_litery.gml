/// @function male_litery(str)
/// @description Zmienia na małe litery.
/// @param {any} str Parametry zgodne z funkcją string_lower.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// male_litery(str);
/// @see string_lower

function male_litery(_str)
{
    return string_lower(_str);
}
