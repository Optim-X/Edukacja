/// @function kod_znaku(char)
/// @description Zwraca kod znaku.
/// @param {any} char Parametry zgodne z funkcją ord.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// kod_znaku(char);
/// @see ord

function kod_znaku(_char)
{
    return ord(_char);
}
