/// @function wielkie_litery(str)
/// @description Zmienia na wielkie litery.
/// @param {any} str Parametry zgodne z funkcją string_upper.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wielkie_litery(str);
/// @see string_upper

function wielkie_litery(_str)
{
    return string_upper(_str);
}
