/// @function czy_tekst(value)
/// @description Sprawdza typ tekstowy.
/// @param {any} value Parametry zgodne z funkcją is_string.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_tekst(value);
/// @see is_string

function czy_tekst(_value)
{
    return is_string(_value);
}
