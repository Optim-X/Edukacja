/// @function pozycja_napisu(substr,str)
/// @description Znajduje tekst.
/// @param {any} substr, str Parametry zgodne z funkcją string_pos.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pozycja_napisu(substr, str);
/// @see string_pos

function pozycja_napisu(_substr, _str)
{
    return string_pos(_substr, _str);
}
