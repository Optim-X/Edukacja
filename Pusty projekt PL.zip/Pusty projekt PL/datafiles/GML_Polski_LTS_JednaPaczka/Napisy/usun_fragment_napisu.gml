/// @function usun_fragment_napisu(str,index,count)
/// @description Usuwa fragment.
/// @param {any} str, index, count Parametry zgodne z funkcją string_delete.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_fragment_napisu(str, index, count);
/// @see string_delete

function usun_fragment_napisu(_str, _index, _count)
{
    return string_delete(_str, _index, _count);
}
