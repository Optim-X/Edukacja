/// @function wstaw_napis(substr,str,index)
/// @description Wstawia tekst.
/// @param {any} substr, str, index Parametry zgodne z funkcją string_insert.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wstaw_napis(substr, str, index);
/// @see string_insert

function wstaw_napis(_substr, _str, _index)
{
    return string_insert(_substr, _str, _index);
}
