/// @function dlugosc_napisu(str)
/// @description Długość napisu.
/// @param {any} str Parametry zgodne z funkcją string_length.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// dlugosc_napisu(str);
/// @see string_length

function dlugosc_napisu(_str)
{
    return string_length(_str);
}
