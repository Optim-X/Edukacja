/// @function komunikat_debug_rozszerzony(message,type)
/// @description Rozszerzony debug.
/// @param {any} message, type Parametry zgodne z funkcją show_debug_message_ext.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// komunikat_debug_rozszerzony(message, type);
/// @see show_debug_message_ext

function komunikat_debug_rozszerzony(_message, _type)
{
    return show_debug_message_ext(_message, _type);
}
