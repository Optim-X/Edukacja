/// @function komunikat_debug(message)
/// @description Komunikat debugowania.
/// @param {any} message Parametry zgodne z funkcją show_debug_message.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// komunikat_debug(message);
/// @see show_debug_message

function komunikat_debug(_message)
{
    return show_debug_message(_message);
}
