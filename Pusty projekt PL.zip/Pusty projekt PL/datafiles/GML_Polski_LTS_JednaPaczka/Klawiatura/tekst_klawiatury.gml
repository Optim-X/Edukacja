/// @function tekst_klawiatury()
/// @description Zwraca tekst klawiatury.
/// @param {any} brak Parametry zgodne z funkcją keyboard_string.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// tekst_klawiatury();
/// @see keyboard_string

function tekst_klawiatury()
{
    return keyboard_string();
}
