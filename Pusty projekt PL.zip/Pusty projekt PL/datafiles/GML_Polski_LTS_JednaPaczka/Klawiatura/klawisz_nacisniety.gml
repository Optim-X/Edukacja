/// @function klawisz_nacisniety(key)
/// @description Sprawdza naciśnięcie.
/// @param {any} key Parametry zgodne z funkcją keyboard_check_pressed.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// klawisz_nacisniety(key);
/// @see keyboard_check_pressed

function klawisz_nacisniety(_key)
{
    return keyboard_check_pressed(_key);
}
