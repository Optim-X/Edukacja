/// @function klawisz(key)
/// @description Sprawdza klawisz.
/// @param {any} key Parametry zgodne z funkcją keyboard_check.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// klawisz(key);
/// @see keyboard_check

function klawisz(_key)
{
    return keyboard_check(_key);
}
