/// @function klawisz_bezposrednio(key)
/// @description Sprawdza fizyczny stan klawisza.
/// @param {any} key Parametry zgodne z funkcją keyboard_check_direct.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// klawisz_bezposrednio(key);
/// @see keyboard_check_direct

function klawisz_bezposrednio(_key)
{
    return keyboard_check_direct(_key);
}
