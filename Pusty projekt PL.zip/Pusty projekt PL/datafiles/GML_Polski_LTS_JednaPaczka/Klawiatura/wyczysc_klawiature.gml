/// @function wyczysc_klawiature()
/// @description Czyści stan klawiatury.
/// @param {any} brak Parametry zgodne z funkcją keyboard_clear.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wyczysc_klawiature();
/// @see keyboard_clear

function wyczysc_klawiature()
{
    return keyboard_clear();
}
