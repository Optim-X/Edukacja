/// @function klawisz_zwolniony(key)
/// @description Sprawdza zwolnienie.
/// @param {any} key Parametry zgodne z funkcją keyboard_check_released.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// klawisz_zwolniony(key);
/// @see keyboard_check_released

function klawisz_zwolniony(_key)
{
    return keyboard_check_released(_key);
}
