/// @function ostatni_klawisz(brak)
/// @description Zwraca kod ostatniego klawisza.
/// @param {any} brak Parametr funkcji.
/// @returns {any} Wartość zwracana przez oryginalną funkcję, jeśli ją posiada.
/// @example
/// ostatni_klawisz();
function ostatni_klawisz()
{
    return keyboard_lastkey();
}
