/// @function pozycja_w_buforze(buffer)
/// @description Pozycja w buforze.
/// @param {any} buffer Parametry zgodne z funkcją buffer_tell.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pozycja_w_buforze(buffer);
/// @see buffer_tell

function pozycja_w_buforze(_buffer)
{
    return buffer_tell(_buffer);
}
