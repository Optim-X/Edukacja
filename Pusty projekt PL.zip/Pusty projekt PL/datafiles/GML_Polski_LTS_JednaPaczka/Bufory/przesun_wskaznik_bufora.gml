/// @function przesun_wskaznik_bufora(buffer,base,offset)
/// @description Przesuwa wskaźnik.
/// @param {any} buffer, base, offset Parametry zgodne z funkcją buffer_seek.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// przesun_wskaznik_bufora(buffer, base, offset);
/// @see buffer_seek

function przesun_wskaznik_bufora(_buffer, _base, _offset)
{
    return buffer_seek(_buffer, _base, _offset);
}
