/// @function rozmiar_bufora(buffer)
/// @description Rozmiar bufora.
/// @param {any} buffer Parametry zgodne z funkcją buffer_get_size.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rozmiar_bufora(buffer);
/// @see buffer_get_size

function rozmiar_bufora(_buffer)
{
    return buffer_get_size(_buffer);
}
