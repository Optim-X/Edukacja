/// @function utworz_bufor(size,type,alignment)
/// @description Tworzy bufor.
/// @param {any} size, type, alignment Parametry zgodne z funkcją buffer_create.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// utworz_bufor(size, type, alignment);
/// @see buffer_create

function utworz_bufor(_size, _type, _alignment)
{
    return buffer_create(_size, _type, _alignment);
}
