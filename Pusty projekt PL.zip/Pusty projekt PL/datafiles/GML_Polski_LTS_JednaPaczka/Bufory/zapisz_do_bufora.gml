/// @function zapisz_do_bufora(buffer,type,value)
/// @description Zapisuje do bufora.
/// @param {any} buffer, type, value Parametry zgodne z funkcją buffer_write.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zapisz_do_bufora(buffer, type, value);
/// @see buffer_write

function zapisz_do_bufora(_buffer, _type, _value)
{
    return buffer_write(_buffer, _type, _value);
}
