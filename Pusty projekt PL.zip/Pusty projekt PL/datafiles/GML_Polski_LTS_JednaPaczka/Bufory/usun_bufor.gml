/// @function usun_bufor(buffer)
/// @description Usuwa bufor.
/// @param {any} buffer Parametry zgodne z funkcją buffer_delete.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_bufor(buffer);
/// @see buffer_delete

function usun_bufor(_buffer)
{
    return buffer_delete(_buffer);
}
