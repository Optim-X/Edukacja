/// @function podejrzyj_bufor(buffer,offset,type)
/// @description Czyta bez zmiany pozycji.
/// @param {any} buffer, offset, type Parametry zgodne z funkcją buffer_peek.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// podejrzyj_bufor(buffer, offset, type);
/// @see buffer_peek

function podejrzyj_bufor(_buffer, _offset, _type)
{
    return buffer_peek(_buffer, _offset, _type);
}
