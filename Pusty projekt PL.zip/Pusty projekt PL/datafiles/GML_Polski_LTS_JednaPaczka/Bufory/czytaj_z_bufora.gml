/// @function czytaj_z_bufora(buffer,type)
/// @description Czyta z bufora.
/// @param {any} buffer, type Parametry zgodne z funkcją buffer_read.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czytaj_z_bufora(buffer, type);
/// @see buffer_read

function czytaj_z_bufora(_buffer, _type)
{
    return buffer_read(_buffer, _type);
}
