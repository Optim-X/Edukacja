/// @function wpisz_w_pozycje_bufora(buffer,offset,type,value)
/// @description Zapisuje pod offset.
/// @param {any} buffer, offset, type, value Parametry zgodne z funkcją buffer_poke.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wpisz_w_pozycje_bufora(buffer, offset, type, value);
/// @see buffer_poke

function wpisz_w_pozycje_bufora(_buffer, _offset, _type, _value)
{
    return buffer_poke(_buffer, _offset, _type, _value);
}
