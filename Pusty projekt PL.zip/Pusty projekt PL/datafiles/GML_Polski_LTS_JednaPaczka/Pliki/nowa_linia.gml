/// @function nowa_linia(file)
/// @description Zapisuje nową linię.
/// @param {any} file Parametry zgodne z funkcją file_text_writeln.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// nowa_linia(file);
/// @see file_text_writeln

function nowa_linia(_file)
{
    return file_text_writeln(_file);
}
