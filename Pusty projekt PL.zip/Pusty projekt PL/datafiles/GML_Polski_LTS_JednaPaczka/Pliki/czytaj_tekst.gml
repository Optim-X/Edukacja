/// @function czytaj_tekst(file)
/// @description Czyta tekst.
/// @param {any} file Parametry zgodne z funkcją file_text_read_string.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czytaj_tekst(file);
/// @see file_text_read_string

function czytaj_tekst(_file)
{
    return file_text_read_string(_file);
}
