/// @function czy_plik_istnieje(filename)
/// @description Sprawdza plik.
/// @param {any} filename Parametry zgodne z funkcją file_exists.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_plik_istnieje(filename);
/// @see file_exists

function czy_plik_istnieje(_filename)
{
    return file_exists(_filename);
}
