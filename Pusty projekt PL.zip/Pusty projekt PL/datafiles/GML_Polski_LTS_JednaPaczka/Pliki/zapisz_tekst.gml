/// @function zapisz_tekst(file,string)
/// @description Zapisuje tekst.
/// @param {any} file, string Parametry zgodne z funkcją file_text_write_string.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zapisz_tekst(file, string);
/// @see file_text_write_string

function zapisz_tekst(_file, _string)
{
    return file_text_write_string(_file, _string);
}
