/// @function zamknij_plik(file)
/// @description Zamyka plik.
/// @param {any} file Parametry zgodne z funkcją file_text_close.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zamknij_plik(file);
/// @see file_text_close

function zamknij_plik(_file)
{
    return file_text_close(_file);
}
