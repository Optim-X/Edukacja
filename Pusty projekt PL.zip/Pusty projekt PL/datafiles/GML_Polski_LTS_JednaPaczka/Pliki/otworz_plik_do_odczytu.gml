/// @function otworz_plik_do_odczytu(filename)
/// @description Otwiera plik do odczytu.
/// @param {any} filename Parametry zgodne z funkcją file_text_open_read.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// otworz_plik_do_odczytu(filename);
/// @see file_text_open_read

function otworz_plik_do_odczytu(_filename)
{
    return file_text_open_read(_filename);
}
