/// @function kopiuj_plik(source,dest)
/// @description Kopiuje plik.
/// @param {any} source, dest Parametry zgodne z funkcją file_copy.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// kopiuj_plik(source, dest);
/// @see file_copy

function kopiuj_plik(_source, _dest)
{
    return file_copy(_source, _dest);
}
