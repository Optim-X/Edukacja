/// @function usun_plik(filename)
/// @description Usuwa plik.
/// @param {any} filename Parametry zgodne z funkcją file_delete.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_plik(filename);
/// @see file_delete

function usun_plik(_filename)
{
    return file_delete(_filename);
}
