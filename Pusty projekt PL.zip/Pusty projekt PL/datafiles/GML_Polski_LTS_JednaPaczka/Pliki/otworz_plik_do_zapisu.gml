/// @function otworz_plik_do_zapisu(filename)
/// @description Otwiera plik do zapisu.
/// @param {any} filename Parametry zgodne z funkcją file_text_open_write.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// otworz_plik_do_zapisu(filename);
/// @see file_text_open_write

function otworz_plik_do_zapisu(_filename)
{
    return file_text_open_write(_filename);
}
