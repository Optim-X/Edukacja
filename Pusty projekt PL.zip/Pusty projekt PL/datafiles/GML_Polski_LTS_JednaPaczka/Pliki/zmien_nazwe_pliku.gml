/// @function zmien_nazwe_pliku(oldname,newname)
/// @description Zmienia nazwę.
/// @param {any} oldname, newname Parametry zgodne z funkcją file_rename.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zmien_nazwe_pliku(oldname, newname);
/// @see file_rename

function zmien_nazwe_pliku(_oldname, _newname)
{
    return file_rename(_oldname, _newname);
}
