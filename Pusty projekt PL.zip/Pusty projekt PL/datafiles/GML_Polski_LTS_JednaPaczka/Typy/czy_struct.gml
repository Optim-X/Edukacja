/// @function czy_struct(value)
/// @description Sprawdza struct.
/// @param {any} value Parametry zgodne z funkcją is_struct.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_struct(value);
/// @see is_struct

function czy_struct(_value)
{
    return is_struct(_value);
}
