/// @function czy_metoda(value)
/// @description Sprawdza metodę.
/// @param {any} value Parametry zgodne z funkcją is_method.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_metoda(value);
/// @see is_method

function czy_metoda(_value)
{
    return is_method(_value);
}
