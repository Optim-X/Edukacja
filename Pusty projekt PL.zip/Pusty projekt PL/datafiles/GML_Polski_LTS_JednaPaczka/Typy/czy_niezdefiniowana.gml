/// @function czy_niezdefiniowana(value)
/// @description Sprawdza undefined.
/// @param {any} value Parametry zgodne z funkcją is_undefined.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_niezdefiniowana(value);
/// @see is_undefined

function czy_niezdefiniowana(_value)
{
    return is_undefined(_value);
}
