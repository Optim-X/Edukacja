/// @function typ_wartosci(value)
/// @description Zwraca typ wartości.
/// @param {any} value Parametry zgodne z funkcją typeof.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// typ_wartosci(value);
/// @see typeof

function typ_wartosci(_value)
{
    return typeof(_value);
}
