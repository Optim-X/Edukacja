/// @function czy_liczba(value)
/// @description Sprawdza liczbę.
/// @param {any} value Parametry zgodne z funkcją is_real.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_liczba(value);
/// @see is_real

function czy_liczba(_value)
{
    return is_real(_value);
}
