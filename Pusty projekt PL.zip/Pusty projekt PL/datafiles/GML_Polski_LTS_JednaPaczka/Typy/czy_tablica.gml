/// @function czy_tablica(value)
/// @description Sprawdza tablicę.
/// @param {any} value Parametry zgodne z funkcją is_array.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_tablica(value);
/// @see is_array

function czy_tablica(_value)
{
    return is_array(_value);
}
