/// @function json_koduj(value)
/// @description Koduje DS do JSON.
/// @param {any} value Parametry zgodne z funkcją json_encode.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// json_koduj(value);
/// @see json_encode

function json_koduj(_value)
{
    return json_encode(_value);
}
