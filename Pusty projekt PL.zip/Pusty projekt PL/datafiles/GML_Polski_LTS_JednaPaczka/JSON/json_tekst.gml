/// @function json_tekst(value,pretty_print,indent)
/// @description Tworzy JSON.
/// @param {any} value, pretty_print, indent Parametry zgodne z funkcją json_stringify.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// json_tekst(value, pretty_print, indent);
/// @see json_stringify

function json_tekst(_value, _pretty_print, _indent)
{
    return json_stringify(_value, _pretty_print, _indent);
}
