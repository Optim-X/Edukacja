/// @function json_parsuj(json,inhibit_string_convert)
/// @description Parsuje JSON.
/// @param {any} json, inhibit_string_convert Parametry zgodne z funkcją json_parse.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// json_parsuj(json, inhibit_string_convert);
/// @see json_parse

function json_parsuj(_json, _inhibit_string_convert)
{
    return json_parse(_json, _inhibit_string_convert);
}
