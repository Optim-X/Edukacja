/// @function json_odkoduj(json)
/// @description Dekoduje JSON do DS.
/// @param {any} json Parametry zgodne z funkcją json_decode.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// json_odkoduj(json);
/// @see json_decode

function json_odkoduj(_json)
{
    return json_decode(_json);
}
