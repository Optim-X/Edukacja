/// @function nazwa_warstwy(layer)
/// @description Nazwa warstwy.
/// @param {any} layer Parametry zgodne z funkcją layer_get_name.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// nazwa_warstwy(layer);
/// @see layer_get_name

function nazwa_warstwy(_layer)
{
    return layer_get_name(_layer);
}
