/// @function ustaw_widocznosc_warstwy(layer,visible)
/// @description Ustawia widoczność.
/// @param {any} layer, visible Parametry zgodne z funkcją layer_set_visible.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_widocznosc_warstwy(layer, visible);
/// @see layer_set_visible

function ustaw_widocznosc_warstwy(_layer, _visible)
{
    return layer_set_visible(_layer, _visible);
}
