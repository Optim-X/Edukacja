/// @function usun_warstwe(layer)
/// @description Usuwa warstwę.
/// @param {any} layer Parametry zgodne z funkcją layer_destroy.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_warstwe(layer);
/// @see layer_destroy

function usun_warstwe(_layer)
{
    return layer_destroy(_layer);
}
