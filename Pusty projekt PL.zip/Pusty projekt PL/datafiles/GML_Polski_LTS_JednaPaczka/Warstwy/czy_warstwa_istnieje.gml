/// @function czy_warstwa_istnieje(layer)
/// @description Sprawdza warstwę.
/// @param {any} layer Parametry zgodne z funkcją layer_exists.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_warstwa_istnieje(layer);
/// @see layer_exists

function czy_warstwa_istnieje(_layer)
{
    return layer_exists(_layer);
}
