/// @function utworz_warstwe(depth,name)
/// @description Tworzy warstwę.
/// @param {any} depth, name Parametry zgodne z funkcją layer_create.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// utworz_warstwe(depth, name);
/// @see layer_create

function utworz_warstwe(_depth, _name)
{
    return layer_create(_depth, _name);
}
