/// @function pobierz_id_warstwy(name)
/// @description Pobiera ID warstwy.
/// @param {any} name Parametry zgodne z funkcją layer_get_id.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pobierz_id_warstwy(name);
/// @see layer_get_id

function pobierz_id_warstwy(_name)
{
    return layer_get_id(_name);
}
