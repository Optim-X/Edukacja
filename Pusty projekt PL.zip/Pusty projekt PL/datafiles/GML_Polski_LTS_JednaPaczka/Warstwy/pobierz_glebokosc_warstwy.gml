/// @function pobierz_glebokosc_warstwy(layer)
/// @description Pobiera głębokość.
/// @param {any} layer Parametry zgodne z funkcją layer_get_depth.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pobierz_glebokosc_warstwy(layer);
/// @see layer_get_depth

function pobierz_glebokosc_warstwy(_layer)
{
    return layer_get_depth(_layer);
}
