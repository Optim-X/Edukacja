/// @function ustaw_glebokosc_warstwy(layer,depth)
/// @description Ustawia głębokość.
/// @param {any} layer, depth Parametry zgodne z funkcją layer_depth.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_glebokosc_warstwy(layer, depth);
/// @see layer_depth

function ustaw_glebokosc_warstwy(_layer, _depth)
{
    return layer_depth(_layer, _depth);
}
