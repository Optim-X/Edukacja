/// @function pobierz_widocznosc_warstwy(layer)
/// @description Pobiera widoczność.
/// @param {any} layer Parametry zgodne z funkcją layer_get_visible.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pobierz_widocznosc_warstwy(layer);
/// @see layer_get_visible

function pobierz_widocznosc_warstwy(_layer)
{
    return layer_get_visible(_layer);
}
