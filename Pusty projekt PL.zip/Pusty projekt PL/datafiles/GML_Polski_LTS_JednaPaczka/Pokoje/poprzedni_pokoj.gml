/// @function poprzedni_pokoj()
/// @description Poprzedni pokój.
/// @param {any} brak Parametry zgodne z funkcją room_goto_previous.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// poprzedni_pokoj();
/// @see room_goto_previous

function poprzedni_pokoj()
{
    return room_goto_previous();
}
