/// @function czy_pokoj_istnieje(room)
/// @description Sprawdza pokój.
/// @param {any} room Parametry zgodne z funkcją room_exists.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_pokoj_istnieje(room);
/// @see room_exists

function czy_pokoj_istnieje(_room)
{
    return room_exists(_room);
}
