/// @function zmien_pokoj(room)
/// @description Przechodzi do pokoju.
/// @param {any} room Parametry zgodne z funkcją room_goto.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zmien_pokoj(room);
/// @see room_goto

function zmien_pokoj(_room)
{
    return room_goto(_room);
}
