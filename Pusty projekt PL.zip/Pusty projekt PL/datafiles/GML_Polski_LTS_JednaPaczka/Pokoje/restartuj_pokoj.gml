/// @function restartuj_pokoj()
/// @description Restartuje pokój.
/// @param {any} brak Parametry zgodne z funkcją room_restart.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// restartuj_pokoj();
/// @see room_restart

function restartuj_pokoj()
{
    return room_restart();
}
