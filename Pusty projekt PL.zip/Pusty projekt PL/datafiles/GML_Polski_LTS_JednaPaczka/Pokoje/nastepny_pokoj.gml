/// @function nastepny_pokoj()
/// @description Następny pokój.
/// @param {any} brak Parametry zgodne z funkcją room_goto_next.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// nastepny_pokoj();
/// @see room_goto_next

function nastepny_pokoj()
{
    return room_goto_next();
}
