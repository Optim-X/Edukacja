/// @function nazwa_pokoju(room)
/// @description Nazwa pokoju.
/// @param {any} room Parametry zgodne z funkcją room_get_name.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// nazwa_pokoju(room);
/// @see room_get_name

function nazwa_pokoju(_room)
{
    return room_get_name(_room);
}
