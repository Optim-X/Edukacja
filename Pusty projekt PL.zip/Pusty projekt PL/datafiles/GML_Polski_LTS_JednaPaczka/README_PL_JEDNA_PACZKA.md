# GML Polski LTS — jedna paczka

Zebrana paczka zawiera poprzednie wersje biblioteki w jednym katalogu oraz mapę funkcji.

Każdy alias jest osobnym skryptem `.gml` i posiada komentarze JSDoc (`@function`, `@description`, `@param`, `@returns`, `@example`) tam, gdzie został przygotowany w katalogu pełnym.

Biblioteka jest warstwą polskich nazw nad GML — nie modyfikuje języka GameMakera ani kompilatora.

## Uwaga
To jest rozszerzony katalog aliasów, a nie gwarantowany, automatycznie wygenerowany 1:1 dump całego API konkretnego buildu LTS. Funkcje zależne od platformy, kontekstu lub specyficznych typów danych należy testować w projekcie.
