/// @function dodaj_do_tablicy(array,value)
/// @description Dodaje element na końcu.
/// @param {any} array, value Parametry zgodne z funkcją array_push.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// dodaj_do_tablicy(array, value);
/// @see array_push

function dodaj_do_tablicy(_array, _value)
{
    return array_push(_array, _value);
}
