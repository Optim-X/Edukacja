/// @function usun_element_tablicy(array,index,count)
/// @description Usuwa elementy.
/// @param {any} array, index, count Parametry zgodne z funkcją array_delete.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_element_tablicy(array, index, count);
/// @see array_delete

function usun_element_tablicy(_array, _index, _count)
{
    return array_delete(_array, _index, _count);
}
