/// @function sortuj_tablice(array,sorttype_or_function)
/// @description Sortuje tablicę.
/// @param {any} array, sorttype_or_function Parametry zgodne z funkcją array_sort.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// sortuj_tablice(array, sorttype_or_function);
/// @see array_sort

function sortuj_tablice(_array, _sorttype_or_function)
{
    return array_sort(_array, _sorttype_or_function);
}
