/// @function ostatni_element(array)
/// @description Ostatni element.
/// @param {any} array Parametry zgodne z funkcją array_last.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ostatni_element(array);
/// @see array_last

function ostatni_element(_array)
{
    return array_last(_array);
}
