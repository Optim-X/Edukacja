/// @function pierwszy_element(array)
/// @description Pierwszy element.
/// @param {any} array Parametry zgodne z funkcją array_first.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pierwszy_element(array);
/// @see array_first

function pierwszy_element(_array)
{
    return array_first(_array);
}
