/// @function dlugosc_tablicy(array)
/// @description Liczba elementów.
/// @param {any} array Parametry zgodne z funkcją array_length.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// dlugosc_tablicy(array);
/// @see array_length

function dlugosc_tablicy(_array)
{
    return array_length(_array);
}
