/// @function odwroc_tablice(array)
/// @description Odwraca tablicę.
/// @param {any} array Parametry zgodne z funkcją array_reverse.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// odwroc_tablice(array);
/// @see array_reverse

function odwroc_tablice(_array)
{
    return array_reverse(_array);
}
