/// @function czy_tablica_zawiera(array,value)
/// @description Sprawdza zawartość.
/// @param {any} array, value Parametry zgodne z funkcją array_contains.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_tablica_zawiera(array, value);
/// @see array_contains

function czy_tablica_zawiera(_array, _value)
{
    return array_contains(_array, _value);
}
