/// @function wstaw_do_tablicy(array,index,value)
/// @description Wstawia element.
/// @param {any} array, index, value Parametry zgodne z funkcją array_insert.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wstaw_do_tablicy(array, index, value);
/// @see array_insert

function wstaw_do_tablicy(_array, _index, _value)
{
    return array_insert(_array, _index, _value);
}
