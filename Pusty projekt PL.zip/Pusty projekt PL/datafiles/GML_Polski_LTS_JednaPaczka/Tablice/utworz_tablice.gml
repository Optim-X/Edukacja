/// @function utworz_tablice(size,value)
/// @description Tworzy tablicę.
/// @param {any} size, value Parametry zgodne z funkcją array_create.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// utworz_tablice(size, value);
/// @see array_create

function utworz_tablice(_size, _value)
{
    return array_create(_size, _value);
}
