/// @function usun_z_tablicy(array)
/// @description Usuwa ostatni element.
/// @param {any} array Parametry zgodne z funkcją array_pop.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_z_tablicy(array);
/// @see array_pop

function usun_z_tablicy(_array)
{
    return array_pop(_array);
}
