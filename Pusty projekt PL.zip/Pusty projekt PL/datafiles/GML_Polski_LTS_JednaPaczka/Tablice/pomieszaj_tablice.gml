/// @function pomieszaj_tablice(array)
/// @description Losowo miesza tablicę.
/// @param {any} array Parametry zgodne z funkcją array_shuffle.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pomieszaj_tablice(array);
/// @see array_shuffle

function pomieszaj_tablice(_array)
{
    return array_shuffle(_array);
}
