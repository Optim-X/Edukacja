/// @function kolizja_punkt(x,y,obj,prec,notme)
/// @description Kolizja punktu.
/// @param {any} x, y, obj, prec, notme Parametry zgodne z funkcją collision_point.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// kolizja_punkt(x, y, obj, prec, notme);
/// @see collision_point

function kolizja_punkt(_x, _y, _obj, _prec, _notme)
{
    return collision_point(_x, _y, _obj, _prec, _notme);
}
