/// @function spotkanie_w_miejscu(x,y,obj)
/// @description Sprawdza kolizję.
/// @param {any} x, y, obj Parametry zgodne z funkcją place_meeting.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// spotkanie_w_miejscu(x, y, obj);
/// @see place_meeting

function spotkanie_w_miejscu(_x, _y, _obj)
{
    return place_meeting(_x, _y, _obj);
}
