/// @function kolizja_kolo(x,y,rad,obj,prec,notme)
/// @description Kolizja koła.
/// @param {any} x, y, rad, obj, prec, notme Parametry zgodne z funkcją collision_circle.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// kolizja_kolo(x, y, rad, obj, prec, notme);
/// @see collision_circle

function kolizja_kolo(_x, _y, _rad, _obj, _prec, _notme)
{
    return collision_circle(_x, _y, _rad, _obj, _prec, _notme);
}
