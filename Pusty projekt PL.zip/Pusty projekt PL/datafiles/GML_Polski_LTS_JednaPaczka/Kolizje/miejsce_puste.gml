/// @function miejsce_puste(x,y)
/// @description Sprawdza wolne miejsce.
/// @param {any} x, y Parametry zgodne z funkcją place_empty.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// miejsce_puste(x, y);
/// @see place_empty

function miejsce_puste(_x, _y)
{
    return place_empty(_x, _y);
}
