/// @function miejsce_wolne(x,y)
/// @description Sprawdza możliwość ruchu.
/// @param {any} x, y Parametry zgodne z funkcją place_free.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// miejsce_wolne(x, y);
/// @see place_free

function miejsce_wolne(_x, _y)
{
    return place_free(_x, _y);
}
