/// @function punkt_w_kole(px,py,cx,cy,rad)
/// @description Punkt w kole.
/// @param {any} px, py, cx, cy, rad Parametry zgodne z funkcją point_in_circle.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// punkt_w_kole(px, py, cx, cy, rad);
/// @see point_in_circle

function punkt_w_kole(_px, _py, _cx, _cy, _rad)
{
    return point_in_circle(_px, _py, _cx, _cy, _rad);
}
