/// @function instancja_w_pozycji(x,y,obj)
/// @description Sprawdza pozycję.
/// @param {any} x, y, obj Parametry zgodne z funkcją instance_position.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// instancja_w_pozycji(x, y, obj);
/// @see instance_position

function instancja_w_pozycji(_x, _y, _obj)
{
    return instance_position(_x, _y, _obj);
}
