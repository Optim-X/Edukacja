/// @function punkt_w_prostokacie(px,py,x1,y1,x2,y2)
/// @description Punkt w prostokącie.
/// @param {any} px, py, x1, y1, x2, y2 Parametry zgodne z funkcją point_in_rectangle.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// punkt_w_prostokacie(px, py, x1, y1, x2, y2);
/// @see point_in_rectangle

function punkt_w_prostokacie(_px, _py, _x1, _y1, _x2, _y2)
{
    return point_in_rectangle(_px, _py, _x1, _y1, _x2, _y2);
}
