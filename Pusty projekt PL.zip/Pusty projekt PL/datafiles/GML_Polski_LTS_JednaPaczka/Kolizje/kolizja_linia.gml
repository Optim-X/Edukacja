/// @function kolizja_linia(x1,y1,x2,y2,obj,prec,notme)
/// @description Kolizja linii.
/// @param {any} x1, y1, x2, y2, obj, prec, notme Parametry zgodne z funkcją collision_line.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// kolizja_linia(x1, y1, x2, y2, obj, prec, notme);
/// @see collision_line

function kolizja_linia(_x1, _y1, _x2, _y2, _obj, _prec, _notme)
{
    return collision_line(_x1, _y1, _x2, _y2, _obj, _prec, _notme);
}
