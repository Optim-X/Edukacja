/// @function miejsce_instancji(x,y,obj)
/// @description Sprawdza instancję w pozycji.
/// @param {any} x, y, obj Parametry zgodne z funkcją instance_place.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// miejsce_instancji(x, y, obj);
/// @see instance_place

function miejsce_instancji(_x, _y, _obj)
{
    return instance_place(_x, _y, _obj);
}
