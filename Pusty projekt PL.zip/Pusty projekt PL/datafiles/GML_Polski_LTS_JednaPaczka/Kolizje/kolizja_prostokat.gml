/// @function kolizja_prostokat(x1,y1,x2,y2,obj,prec,notme)
/// @description Kolizja prostokąta.
/// @param {any} x1, y1, x2, y2, obj, prec, notme Parametry zgodne z funkcją collision_rectangle.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// kolizja_prostokat(x1, y1, x2, y2, obj, prec, notme);
/// @see collision_rectangle

function kolizja_prostokat(_x1, _y1, _x2, _y2, _obj, _prec, _notme)
{
    return collision_rectangle(_x1, _y1, _x2, _y2, _obj, _prec, _notme);
}
