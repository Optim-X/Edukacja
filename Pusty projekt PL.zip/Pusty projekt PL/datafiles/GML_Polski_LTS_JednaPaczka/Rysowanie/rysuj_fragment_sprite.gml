/// @function rysuj_fragment_sprite(sprite,subimg,left,top,width,height,x,y)
/// @description Rysuje fragment sprite.
/// @param {any} sprite, subimg, left, top, width, height, x, y Parametry zgodne z funkcją draw_sprite_part.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_fragment_sprite(sprite, subimg, left, top, width, height, x, y);
/// @see draw_sprite_part

function rysuj_fragment_sprite(_sprite, _subimg, _left, _top, _width, _height, _x, _y)
{
    return draw_sprite_part(_sprite, _subimg, _left, _top, _width, _height, _x, _y);
}
