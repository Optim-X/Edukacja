/// @function rysuj_trojkat(x1,y1,x2,y2,x3,y3,outline)
/// @description Rysuje trójkąt.
/// @param {any} x1, y1, x2, y2, x3, y3, outline Parametry zgodne z funkcją draw_triangle.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_trojkat(x1, y1, x2, y2, x3, y3, outline);
/// @see draw_triangle

function rysuj_trojkat(_x1, _y1, _x2, _y2, _x3, _y3, _outline)
{
    return draw_triangle(_x1, _y1, _x2, _y2, _x3, _y3, _outline);
}
