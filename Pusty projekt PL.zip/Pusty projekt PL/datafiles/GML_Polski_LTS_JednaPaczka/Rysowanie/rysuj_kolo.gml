/// @function rysuj_kolo(x,y,r,outline)
/// @description Rysuje koło.
/// @param {any} x, y, r, outline Parametry zgodne z funkcją draw_circle.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_kolo(x, y, r, outline);
/// @see draw_circle

function rysuj_kolo(_x, _y, _r, _outline)
{
    return draw_circle(_x, _y, _r, _outline);
}
