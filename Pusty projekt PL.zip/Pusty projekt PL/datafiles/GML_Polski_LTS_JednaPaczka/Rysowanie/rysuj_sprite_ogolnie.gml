/// @function rysuj_sprite_ogolnie(sprite,subimg,left,top,width,height,x,y,xscale,yscale,rot,c1,c2,c3,c4,alpha)
/// @description Pełna kontrola rysowania sprite.
/// @param {any} sprite, subimg, left, top, width, height, x, y, xscale, yscale, rot, c1, c2, c3, c4, alpha Parametry zgodne z funkcją draw_sprite_general.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_sprite_ogolnie(sprite, subimg, left, top, width, height, x, y, xscale, yscale, rot, c1, c2, c3, c4, alpha);
/// @see draw_sprite_general

function rysuj_sprite_ogolnie(_sprite, _subimg, _left, _top, _width, _height, _x, _y, _xscale, _yscale, _rot, _c1, _c2, _c3, _c4, _alpha)
{
    return draw_sprite_general(_sprite, _subimg, _left, _top, _width, _height, _x, _y, _xscale, _yscale, _rot, _c1, _c2, _c3, _c4, _alpha);
}
