/// @function rysuj_tekst_rozszerzony(x,y,string,sep,w)
/// @description Rysuje tekst z łamaniem.
/// @param {any} x, y, string, sep, w Parametry zgodne z funkcją draw_text_ext.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_tekst_rozszerzony(x, y, string, sep, w);
/// @see draw_text_ext

function rysuj_tekst_rozszerzony(_x, _y, _string, _sep, _w)
{
    return draw_text_ext(_x, _y, _string, _sep, _w);
}
