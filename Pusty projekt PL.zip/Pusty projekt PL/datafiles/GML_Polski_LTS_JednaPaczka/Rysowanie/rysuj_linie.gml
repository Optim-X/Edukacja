/// @function rysuj_linie(x1,y1,x2,y2)
/// @description Rysuje linię.
/// @param {any} x1, y1, x2, y2 Parametry zgodne z funkcją draw_line.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_linie(x1, y1, x2, y2);
/// @see draw_line

function rysuj_linie(_x1, _y1, _x2, _y2)
{
    return draw_line(_x1, _y1, _x2, _y2);
}
