/// @function ustaw_przezroczystosc(alpha)
/// @description Ustawia alfa.
/// @param {any} alpha Parametry zgodne z funkcją draw_set_alpha.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_przezroczystosc(alpha);
/// @see draw_set_alpha

function ustaw_przezroczystosc(_alpha)
{
    return draw_set_alpha(_alpha);
}
