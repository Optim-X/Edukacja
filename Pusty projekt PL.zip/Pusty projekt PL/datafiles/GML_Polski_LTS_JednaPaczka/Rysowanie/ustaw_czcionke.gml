/// @function ustaw_czcionke(font)
/// @description Ustawia czcionkę.
/// @param {any} font Parametry zgodne z funkcją draw_set_font.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_czcionke(font);
/// @see draw_set_font

function ustaw_czcionke(_font)
{
    return draw_set_font(_font);
}
