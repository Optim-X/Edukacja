/// @function rysuj_elipse(x1,y1,x2,y2,outline)
/// @description Rysuje elipsę.
/// @param {any} x1, y1, x2, y2, outline Parametry zgodne z funkcją draw_ellipse.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_elipse(x1, y1, x2, y2, outline);
/// @see draw_ellipse

function rysuj_elipse(_x1, _y1, _x2, _y2, _outline)
{
    return draw_ellipse(_x1, _y1, _x2, _y2, _outline);
}
