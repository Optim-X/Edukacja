/// @function rysuj_tekst(x,y,string)
/// @description Rysuje tekst.
/// @param {any} x, y, string Parametry zgodne z funkcją draw_text.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_tekst(x, y, string);
/// @see draw_text

function rysuj_tekst(_x, _y, _string)
{
    return draw_text(_x, _y, _string);
}
