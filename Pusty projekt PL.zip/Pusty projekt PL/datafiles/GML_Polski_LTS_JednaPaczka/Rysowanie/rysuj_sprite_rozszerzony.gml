/// @function rysuj_sprite_rozszerzony(sprite,subimg,x,y,xscale,yscale,rot,color,alpha)
/// @description Rysuje sprite z transformacją.
/// @param {any} sprite, subimg, x, y, xscale, yscale, rot, color, alpha Parametry zgodne z funkcją draw_sprite_ext.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_sprite_rozszerzony(sprite, subimg, x, y, xscale, yscale, rot, color, alpha);
/// @see draw_sprite_ext

function rysuj_sprite_rozszerzony(_sprite, _subimg, _x, _y, _xscale, _yscale, _rot, _color, _alpha)
{
    return draw_sprite_ext(_sprite, _subimg, _x, _y, _xscale, _yscale, _rot, _color, _alpha);
}
