/// @function rysuj_sprite(sprite,subimg,x,y)
/// @description Rysuje sprite.
/// @param {any} sprite, subimg, x, y Parametry zgodne z funkcją draw_sprite.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_sprite(sprite, subimg, x, y);
/// @see draw_sprite

function rysuj_sprite(_sprite, _subimg, _x, _y)
{
    return draw_sprite(_sprite, _subimg, _x, _y);
}
