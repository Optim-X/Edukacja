/// @function ustaw_kolor(color)
/// @description Ustawia kolor.
/// @param {any} color Parametry zgodne z funkcją draw_set_color.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_kolor(color);
/// @see draw_set_color

function ustaw_kolor(_color)
{
    return draw_set_color(_color);
}
