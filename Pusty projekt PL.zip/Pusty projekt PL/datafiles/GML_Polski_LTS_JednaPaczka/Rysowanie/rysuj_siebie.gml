/// @function rysuj_siebie()
/// @description Rysuje bieżącą instancję.
/// @param {any} brak Parametry zgodne z funkcją draw_self.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_siebie();
/// @see draw_self

function rysuj_siebie()
{
    return draw_self();
}
