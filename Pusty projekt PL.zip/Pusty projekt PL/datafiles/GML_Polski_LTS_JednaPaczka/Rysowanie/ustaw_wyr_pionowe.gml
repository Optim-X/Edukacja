/// @function ustaw_wyr_pionowe(align)
/// @description Wyrównanie pionowe.
/// @param {any} align Parametry zgodne z funkcją draw_set_valign.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_wyr_pionowe(align);
/// @see draw_set_valign

function ustaw_wyr_pionowe(_align)
{
    return draw_set_valign(_align);
}
