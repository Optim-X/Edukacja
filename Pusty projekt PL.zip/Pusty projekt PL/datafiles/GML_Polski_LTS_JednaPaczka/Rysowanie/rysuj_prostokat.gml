/// @function rysuj_prostokat(x1,y1,x2,y2,outline)
/// @description Rysuje prostokąt.
/// @param {any} x1, y1, x2, y2, outline Parametry zgodne z funkcją draw_rectangle.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rysuj_prostokat(x1, y1, x2, y2, outline);
/// @see draw_rectangle

function rysuj_prostokat(_x1, _y1, _x2, _y2, _outline)
{
    return draw_rectangle(_x1, _y1, _x2, _y2, _outline);
}
