/// @function ustaw_wyr_poziome(align)
/// @description Wyrównanie poziome.
/// @param {any} align Parametry zgodne z funkcją draw_set_halign.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_wyr_poziome(align);
/// @see draw_set_halign

function ustaw_wyr_poziome(_align)
{
    return draw_set_halign(_align);
}
