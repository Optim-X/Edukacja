# Źródła i uwagi

Pakiet jest przygotowany jako warstwa edukacyjna nad GML. Dokumentacja LTS GameMaker zawiera referencję funkcji, a JSDoc własnych funkcji jest wykorzystywany przez edytor do podpowiedzi.

Weryfikacja nazw i kategorii: oficjalna dokumentacja GameMaker LTS.
