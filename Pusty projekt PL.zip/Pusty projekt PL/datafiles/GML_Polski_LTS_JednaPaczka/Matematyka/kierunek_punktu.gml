/// @function kierunek_punktu(x1,y1,x2,y2)
/// @description Kierunek do punktu.
/// @param {any} x1, y1, x2, y2 Parametry zgodne z funkcją point_direction.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// kierunek_punktu(x1, y1, x2, y2);
/// @see point_direction

function kierunek_punktu(_x1, _y1, _x2, _y2)
{
    return point_direction(_x1, _y1, _x2, _y2);
}
