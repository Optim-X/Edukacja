/// @function wartosc_bezwzgledna(x)
/// @description Wartość bezwzględna.
/// @param {any} x Parametry zgodne z funkcją abs.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wartosc_bezwzgledna(x);
/// @see abs

function wartosc_bezwzgledna(_x)
{
    return abs(_x);
}
