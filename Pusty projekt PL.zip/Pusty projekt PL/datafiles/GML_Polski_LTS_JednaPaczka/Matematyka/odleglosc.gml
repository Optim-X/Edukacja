/// @function odleglosc(x1,y1,x2,y2)
/// @description Odległość między punktami.
/// @param {any} x1, y1, x2, y2 Parametry zgodne z funkcją point_distance.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// odleglosc(x1, y1, x2, y2);
/// @see point_distance

function odleglosc(_x1, _y1, _x2, _y2)
{
    return point_distance(_x1, _y1, _x2, _y2);
}
