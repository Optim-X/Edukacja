/// @function znak(x)
/// @description Znak liczby.
/// @param {any} x Parametry zgodne z funkcją sign.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// znak(x);
/// @see sign

function znak(_x)
{
    return sign(_x);
}
