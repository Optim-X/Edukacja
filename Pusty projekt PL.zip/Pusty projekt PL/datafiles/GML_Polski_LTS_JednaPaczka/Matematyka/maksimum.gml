/// @function maksimum(a,b)
/// @description Większa wartość.
/// @param {any} a, b Parametry zgodne z funkcją max.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// maksimum(a, b);
/// @see max

function maksimum(_a, _b)
{
    return max(_a, _b);
}
