/// @function losowa(x)
/// @description Losowa liczba rzeczywista.
/// @param {any} x Parametry zgodne z funkcją random.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// losowa(x);
/// @see random

function losowa(_x)
{
    return random(_x);
}
