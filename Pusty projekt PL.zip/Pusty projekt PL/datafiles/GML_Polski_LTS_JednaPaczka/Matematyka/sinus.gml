/// @function sinus(x)
/// @description Sinus kąta.
/// @param {any} x Parametry zgodne z funkcją sin.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// sinus(x);
/// @see sin

function sinus(_x)
{
    return sin(_x);
}
