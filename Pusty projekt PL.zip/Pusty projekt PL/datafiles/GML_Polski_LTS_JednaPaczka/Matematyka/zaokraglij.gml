/// @function zaokraglij(x)
/// @description Zaokrągla do najbliższej liczby.
/// @param {any} x Parametry zgodne z funkcją round.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zaokraglij(x);
/// @see round

function zaokraglij(_x)
{
    return round(_x);
}
