/// @function zaokraglij_w_dol(x)
/// @description Zaokrągla w dół.
/// @param {any} x Parametry zgodne z funkcją floor.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zaokraglij_w_dol(x);
/// @see floor

function zaokraglij_w_dol(_x)
{
    return floor(_x);
}
