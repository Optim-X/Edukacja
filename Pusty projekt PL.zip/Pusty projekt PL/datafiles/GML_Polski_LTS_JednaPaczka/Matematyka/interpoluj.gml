/// @function interpoluj(a,b,t)
/// @description Interpolacja liniowa.
/// @param {any} a, b, t Parametry zgodne z funkcją lerp.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// interpoluj(a, b, t);
/// @see lerp

function interpoluj(_a, _b, _t)
{
    return lerp(_a, _b, _t);
}
