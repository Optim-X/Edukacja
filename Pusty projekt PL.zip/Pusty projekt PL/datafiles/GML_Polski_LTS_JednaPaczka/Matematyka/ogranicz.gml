/// @function ogranicz(value,min,max)
/// @description Ogranicza wartość do zakresu.
/// @param {any} value, min, max Parametry zgodne z funkcją clamp.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ogranicz(value, min, max);
/// @see clamp

function ogranicz(_value, _min, _max)
{
    return clamp(_value, _min, _max);
}
