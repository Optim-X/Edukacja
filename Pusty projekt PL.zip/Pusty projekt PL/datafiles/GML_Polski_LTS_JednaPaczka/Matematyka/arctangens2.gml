/// @function arctangens2(y,x)
/// @description Arcus tangens dwóch składowych.
/// @param {any} y, x Parametry zgodne z funkcją arctan2.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// arctangens2(y, x);
/// @see arctan2

function arctangens2(_y, _x)
{
    return arctan2(_y, _x);
}
