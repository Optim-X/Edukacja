/// @function potega(x,y)
/// @description Potęguje liczbę.
/// @param {any} x, y Parametry zgodne z funkcją power.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// potega(x, y);
/// @see power

function potega(_x, _y)
{
    return power(_x, _y);
}
