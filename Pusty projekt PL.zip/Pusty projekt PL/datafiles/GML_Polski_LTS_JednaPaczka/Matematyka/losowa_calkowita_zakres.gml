/// @function losowa_calkowita_zakres(a,b)
/// @description Losuje całkowitą z zakresu.
/// @param {any} a, b Parametry zgodne z funkcją irandom_range.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// losowa_calkowita_zakres(a, b);
/// @see irandom_range

function losowa_calkowita_zakres(_a, _b)
{
    return irandom_range(_a, _b);
}
