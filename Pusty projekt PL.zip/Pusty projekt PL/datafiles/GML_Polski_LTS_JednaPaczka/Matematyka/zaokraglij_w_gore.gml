/// @function zaokraglij_w_gore(x)
/// @description Zaokrągla w górę.
/// @param {any} x Parametry zgodne z funkcją ceil.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zaokraglij_w_gore(x);
/// @see ceil

function zaokraglij_w_gore(_x)
{
    return ceil(_x);
}
