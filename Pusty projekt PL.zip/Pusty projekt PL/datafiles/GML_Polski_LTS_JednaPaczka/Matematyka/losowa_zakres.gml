/// @function losowa_zakres(a,b)
/// @description Losuje z zakresu.
/// @param {any} a, b Parametry zgodne z funkcją random_range.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// losowa_zakres(a, b);
/// @see random_range

function losowa_zakres(_a, _b)
{
    return random_range(_a, _b);
}
