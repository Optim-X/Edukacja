/// @function cosinus(x)
/// @description Cosinus kąta.
/// @param {any} x Parametry zgodne z funkcją cos.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// cosinus(x);
/// @see cos

function cosinus(_x)
{
    return cos(_x);
}
