/// @function pierwiastek(x)
/// @description Pierwiastek kwadratowy.
/// @param {any} x Parametry zgodne z funkcją sqrt.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pierwiastek(x);
/// @see sqrt

function pierwiastek(_x)
{
    return sqrt(_x);
}
