/// @function czesc_ulamkowa(x)
/// @description Część ułamkowa.
/// @param {any} x Parametry zgodne z funkcją frac.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czesc_ulamkowa(x);
/// @see frac

function czesc_ulamkowa(_x)
{
    return frac(_x);
}
