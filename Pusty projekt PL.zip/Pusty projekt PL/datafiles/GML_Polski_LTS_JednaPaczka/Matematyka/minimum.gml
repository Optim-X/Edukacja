/// @function minimum(a,b)
/// @description Mniejsza wartość.
/// @param {any} a, b Parametry zgodne z funkcją min.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// minimum(a, b);
/// @see min

function minimum(_a, _b)
{
    return min(_a, _b);
}
