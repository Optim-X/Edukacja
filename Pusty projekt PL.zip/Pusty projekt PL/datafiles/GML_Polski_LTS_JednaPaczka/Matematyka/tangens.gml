/// @function tangens(x)
/// @description Tangens kąta.
/// @param {any} x Parametry zgodne z funkcją tan.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// tangens(x);
/// @see tan

function tangens(_x)
{
    return tan(_x);
}
