/// @function losowa_calkowita(n)
/// @description Losowa liczba całkowita.
/// @param {any} n Parametry zgodne z funkcją irandom.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// losowa_calkowita(n);
/// @see irandom

function losowa_calkowita(_n)
{
    return irandom(_n);
}
