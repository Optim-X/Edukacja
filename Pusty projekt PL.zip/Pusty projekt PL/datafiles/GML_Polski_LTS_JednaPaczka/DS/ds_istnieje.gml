/// @function ds_istnieje(id,type)
/// @description Sprawdza strukturę DS.
/// @param {any} id, type Parametry zgodne z funkcją ds_exists.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ds_istnieje(id, type);
/// @see ds_exists

function ds_istnieje(_id, _type)
{
    return ds_exists(_id, _type);
}
