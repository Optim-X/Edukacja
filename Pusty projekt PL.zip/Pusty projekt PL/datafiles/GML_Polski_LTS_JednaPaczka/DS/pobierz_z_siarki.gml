/// @function pobierz_z_siarki(id,x,y)
/// @description Pobiera komórkę.
/// @param {any} id, x, y Parametry zgodne z funkcją ds_grid_get.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pobierz_z_siarki(id, x, y);
/// @see ds_grid_get

function pobierz_z_siarki(_id, _x, _y)
{
    return ds_grid_get(_id, _x, _y);
}
