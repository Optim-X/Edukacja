/// @function znajdz_wartosc_w_mapie(id,key)
/// @description Znajduje wartość.
/// @param {any} id, key Parametry zgodne z funkcją ds_map_find_value.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// znajdz_wartosc_w_mapie(id, key);
/// @see ds_map_find_value

function znajdz_wartosc_w_mapie(_id, _key)
{
    return ds_map_find_value(_id, _key);
}
