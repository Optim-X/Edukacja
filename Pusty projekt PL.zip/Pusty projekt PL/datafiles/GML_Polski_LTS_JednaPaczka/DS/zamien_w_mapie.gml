/// @function zamien_w_mapie(id,key,value)
/// @description Zastępuje wartość.
/// @param {any} id, key, value Parametry zgodne z funkcją ds_map_replace.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zamien_w_mapie(id, key, value);
/// @see ds_map_replace

function zamien_w_mapie(_id, _key, _value)
{
    return ds_map_replace(_id, _key, _value);
}
