/// @function usun_siarke(id)
/// @description Usuwa grid.
/// @param {any} id Parametry zgodne z funkcją ds_grid_destroy.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_siarke(id);
/// @see ds_grid_destroy

function usun_siarke(_id)
{
    return ds_grid_destroy(_id);
}
