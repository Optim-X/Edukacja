/// @function utworz_siarke(w,h)
/// @description Tworzy grid.
/// @param {any} w, h Parametry zgodne z funkcją ds_grid_create.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// utworz_siarke(w, h);
/// @see ds_grid_create

function utworz_siarke(_w, _h)
{
    return ds_grid_create(_w, _h);
}
