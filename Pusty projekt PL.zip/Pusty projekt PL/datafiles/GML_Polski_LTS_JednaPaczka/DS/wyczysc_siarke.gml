/// @function wyczysc_siarke(id,value)
/// @description Czyści grid.
/// @param {any} id, value Parametry zgodne z funkcją ds_grid_clear.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wyczysc_siarke(id, value);
/// @see ds_grid_clear

function wyczysc_siarke(_id, _value)
{
    return ds_grid_clear(_id, _value);
}
