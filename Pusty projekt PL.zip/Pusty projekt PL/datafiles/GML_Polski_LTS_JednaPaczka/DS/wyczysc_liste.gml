/// @function wyczysc_liste(id)
/// @description Czyści listę.
/// @param {any} id Parametry zgodne z funkcją ds_list_clear.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wyczysc_liste(id);
/// @see ds_list_clear

function wyczysc_liste(_id)
{
    return ds_list_clear(_id);
}
