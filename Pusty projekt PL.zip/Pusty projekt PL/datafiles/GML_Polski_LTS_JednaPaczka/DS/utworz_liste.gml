/// @function utworz_liste()
/// @description Tworzy listę.
/// @param {any} brak Parametry zgodne z funkcją ds_list_create.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// utworz_liste();
/// @see ds_list_create

function utworz_liste()
{
    return ds_list_create();
}
