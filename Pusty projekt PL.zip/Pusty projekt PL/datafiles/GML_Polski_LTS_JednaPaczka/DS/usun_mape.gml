/// @function usun_mape(id)
/// @description Usuwa mapę.
/// @param {any} id Parametry zgodne z funkcją ds_map_destroy.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_mape(id);
/// @see ds_map_destroy

function usun_mape(_id)
{
    return ds_map_destroy(_id);
}
