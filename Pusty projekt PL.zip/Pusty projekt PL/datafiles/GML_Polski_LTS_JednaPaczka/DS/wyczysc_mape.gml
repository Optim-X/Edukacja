/// @function wyczysc_mape(id)
/// @description Czyści mapę.
/// @param {any} id Parametry zgodne z funkcją ds_map_clear.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wyczysc_mape(id);
/// @see ds_map_clear

function wyczysc_mape(_id)
{
    return ds_map_clear(_id);
}
