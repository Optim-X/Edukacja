/// @function usun_z_mapy(id,key)
/// @description Usuwa klucz.
/// @param {any} id, key Parametry zgodne z funkcją ds_map_delete.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_z_mapy(id, key);
/// @see ds_map_delete

function usun_z_mapy(_id, _key)
{
    return ds_map_delete(_id, _key);
}
