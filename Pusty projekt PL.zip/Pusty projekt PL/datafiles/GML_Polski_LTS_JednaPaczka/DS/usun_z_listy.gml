/// @function usun_z_listy(id,pos)
/// @description Usuwa element.
/// @param {any} id, pos Parametry zgodne z funkcją ds_list_delete.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_z_listy(id, pos);
/// @see ds_list_delete

function usun_z_listy(_id, _pos)
{
    return ds_list_delete(_id, _pos);
}
