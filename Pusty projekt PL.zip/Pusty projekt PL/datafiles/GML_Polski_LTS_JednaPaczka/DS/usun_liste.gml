/// @function usun_liste(id)
/// @description Usuwa listę.
/// @param {any} id Parametry zgodne z funkcją ds_list_destroy.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_liste(id);
/// @see ds_list_destroy

function usun_liste(_id)
{
    return ds_list_destroy(_id);
}
