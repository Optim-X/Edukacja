/// @function ustaw_w_siarke(id,x,y,value)
/// @description Ustawia komórkę.
/// @param {any} id, x, y, value Parametry zgodne z funkcją ds_grid_set.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_w_siarke(id, x, y, value);
/// @see ds_grid_set

function ustaw_w_siarke(_id, _x, _y, _value)
{
    return ds_grid_set(_id, _x, _y, _value);
}
