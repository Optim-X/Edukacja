/// @function wysokosc_siarki(id)
/// @description Wysokość gridu.
/// @param {any} id Parametry zgodne z funkcją ds_grid_height.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wysokosc_siarki(id);
/// @see ds_grid_height

function wysokosc_siarki(_id)
{
    return ds_grid_height(_id);
}
