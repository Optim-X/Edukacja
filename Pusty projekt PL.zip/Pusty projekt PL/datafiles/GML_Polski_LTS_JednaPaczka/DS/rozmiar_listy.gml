/// @function rozmiar_listy(id)
/// @description Rozmiar listy.
/// @param {any} id Parametry zgodne z funkcją ds_list_size.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rozmiar_listy(id);
/// @see ds_list_size

function rozmiar_listy(_id)
{
    return ds_list_size(_id);
}
