/// @function rozmiar_mapy(id)
/// @description Rozmiar mapy.
/// @param {any} id Parametry zgodne z funkcją ds_map_size.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rozmiar_mapy(id);
/// @see ds_map_size

function rozmiar_mapy(_id)
{
    return ds_map_size(_id);
}
