/// @function sortuj_liste(id,asc)
/// @description Sortuje listę.
/// @param {any} id, asc Parametry zgodne z funkcją ds_list_sort.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// sortuj_liste(id, asc);
/// @see ds_list_sort

function sortuj_liste(_id, _asc)
{
    return ds_list_sort(_id, _asc);
}
