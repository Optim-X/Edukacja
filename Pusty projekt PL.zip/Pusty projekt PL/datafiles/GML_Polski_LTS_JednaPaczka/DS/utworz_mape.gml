/// @function utworz_mape( )
/// @description Tworzy DS Map.
/// @param {any} brak Parametry zgodne z funkcją ds_map_create.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// utworz_mape();
/// @see ds_map_create

function utworz_mape()
{
    return ds_map_create();
}
