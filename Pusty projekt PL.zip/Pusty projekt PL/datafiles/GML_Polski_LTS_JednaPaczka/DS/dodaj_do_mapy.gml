/// @function dodaj_do_mapy(id,key,value)
/// @description Dodaje parę.
/// @param {any} id, key, value Parametry zgodne z funkcją ds_map_add.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// dodaj_do_mapy(id, key, value);
/// @see ds_map_add

function dodaj_do_mapy(_id, _key, _value)
{
    return ds_map_add(_id, _key, _value);
}
