/// @function czy_klucz_w_mapie(id,key)
/// @description Sprawdza klucz.
/// @param {any} id, key Parametry zgodne z funkcją ds_map_exists.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_klucz_w_mapie(id, key);
/// @see ds_map_exists

function czy_klucz_w_mapie(_id, _key)
{
    return ds_map_exists(_id, _key);
}
