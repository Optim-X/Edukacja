/// @function dodaj_do_listy(id,value)
/// @description Dodaje element.
/// @param {any} id, value Parametry zgodne z funkcją ds_list_add.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// dodaj_do_listy(id, value);
/// @see ds_list_add

function dodaj_do_listy(_id, _value)
{
    return ds_list_add(_id, _value);
}
