/// @function pomieszaj_liste(id)
/// @description Miesza listę.
/// @param {any} id Parametry zgodne z funkcją ds_list_shuffle.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pomieszaj_liste(id);
/// @see ds_list_shuffle

function pomieszaj_liste(_id)
{
    return ds_list_shuffle(_id);
}
