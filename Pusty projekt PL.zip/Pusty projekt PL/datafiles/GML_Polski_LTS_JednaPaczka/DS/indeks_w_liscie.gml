/// @function indeks_w_liscie(id,value)
/// @description Znajduje indeks.
/// @param {any} id, value Parametry zgodne z funkcją ds_list_find_index.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// indeks_w_liscie(id, value);
/// @see ds_list_find_index

function indeks_w_liscie(_id, _value)
{
    return ds_list_find_index(_id, _value);
}
