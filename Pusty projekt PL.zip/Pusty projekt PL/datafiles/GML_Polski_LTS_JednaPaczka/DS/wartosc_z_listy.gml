/// @function wartosc_z_listy(id,pos)
/// @description Pobiera wartość.
/// @param {any} id, pos Parametry zgodne z funkcją ds_list_find_value.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wartosc_z_listy(id, pos);
/// @see ds_list_find_value

function wartosc_z_listy(_id, _pos)
{
    return ds_list_find_value(_id, _pos);
}
