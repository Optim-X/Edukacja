/// @function szerokosc_siarki(id)
/// @description Szerokość gridu.
/// @param {any} id Parametry zgodne z funkcją ds_grid_width.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// szerokosc_siarki(id);
/// @see ds_grid_width

function szerokosc_siarki(_id)
{
    return ds_grid_width(_id);
}
