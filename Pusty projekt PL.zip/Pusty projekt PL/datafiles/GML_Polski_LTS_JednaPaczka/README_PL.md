# GML Polski LTS

Polskie odpowiedniki funkcji GML jako osobne skrypty. Funkcje są wrapperami: polska funkcja wywołuje natywną funkcję GameMakera. Każdy plik zawiera JSDoc po polsku: `@function`, `@description`, `@param`, `@returns`, `@example` oraz `@see`.

## Instalacja
Skopiuj foldery kategorii do projektu i dodaj skrypty do Asset Browser.

## Przykład
```gml
var tekst = "GameMaker";
var n = dlugosc_napisu(tekst);
rysuj_tekst(100, 100, tekst);
```

## Uwaga
Nazwy polskie nie zastępują składni GML. Nadal obowiązują oryginalne typy, stałe, zasady zakresu i parametry GameMakera. Część funkcji zależnych od platformy może działać tylko na określonych targetach. Przed użyciem sprawdź dokumentację LTS.

Dokumentacja: https://manual.gamemaker.io/lts/en/GameMaker_Language/GML_Reference/GML_Reference.htm
