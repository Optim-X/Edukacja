// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function istnieje_plik(fname) {
    return file_exists(fname);
}

function usun_plik(fname) {
    return file_delete(fname);
}

function kopiuj_plik(fname,newname) {
    return file_copy(fname,newname);
}

function przenies_plik(fname,newname) {
    return file_rename(fname,newname);
}

function otworz_plik_tekst_odczyt(fname) {
    return file_text_open_read(fname);
}

function otworz_plik_tekst_zapis(fname) {
    return file_text_open_write(fname);
}

function czytaj_linie(file) {
    return file_text_read_string(file);
}

function zapisz_linie(file,str) {
    return file_text_write_string(file,str);
}

function nowa_linia(file) {
    return file_text_writeln(file);
}

function zamknij_plik_tekst(file) {
    return file_text_close(file);
}

function istnieje_katalog(dir) {
    return directory_exists(dir);
}

function utworz_katalog(dir) {
    return directory_create(dir);
}

function usun_katalog(dir) {
    return directory_destroy(dir);
}
