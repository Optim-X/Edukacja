// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function puste_miejsce(x,y,obj) {
    return place_empty(x,y,obj);
}

function wolne_miejsce(x,y,obj) {
    return place_free(x,y,obj);
}

function spotkanie(x,y,obj) {
    return place_meeting(x,y,obj);
}

function kolizja_punkt(x,y,obj,prec,notme) {
    return collision_point(x,y,obj,prec,notme);
}

function kolizja_linia(x1,y1,x2,y2,obj,prec,notme) {
    return collision_line(x1,y1,x2,y2,obj,prec,notme);
}

function kolizja_kolo(x,y,radius,obj,prec,notme) {
    return collision_circle(x,y,radius,obj,prec,notme);
}

function kolizja_elipsa(x1,y1,x2,y2,obj,prec,notme) {
    return collision_ellipse(x1,y1,x2,y2,obj,prec,notme);
}

function kolizja_prostokat(x1,y1,x2,y2,obj,prec,notme) {
    return collision_rectangle(x1,y1,x2,y2,obj,prec,notme);
}

function punkt_w_prostokacie(px,py,x1,y1,x2,y2) {
    return point_in_rectangle(px,py,x1,y1,x2,y2);
}

function punkt_w_kole(px,py,cx,cy,radius) {
    return point_in_circle(px,py,cx,cy,radius);
}
