// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function rysuj_sprite(sprite,subimg,x,y) {
    return draw_sprite(sprite,subimg,x,y);
}

function rysuj_sprite_rozszerzony(sprite,subimg,x,y,xscale,yscale,rot,color,alpha) {
    return draw_sprite_ext(sprite,subimg,x,y,xscale,yscale,rot,color,alpha);
}

function rysuj_tekst(x,y,string) {
    return draw_text(x,y,string);
}

function rysuj_tekst_rozszerzony(x,y,string,sep,w,halign,valign) {
    return draw_text_ext(x,y,string,sep,w,halign,valign);
}

function rysuj_linie(x1,y1,x2,y2) {
    return draw_line(x1,y1,x2,y2);
}

function rysuj_linie_szeroka(x1,y1,x2,y2,width) {
    return draw_line_width(x1,y1,x2,y2,width);
}

function rysuj_punkt(x,y) {
    return draw_point(x,y);
}

function rysuj_okrag(x,y,radius,outline) {
    return draw_circle(x,y,radius,outline);
}

function rysuj_elipse(x1,y1,x2,y2,outline) {
    return draw_ellipse(x1,y1,x2,y2,outline);
}

function rysuj_prostokat(x1,y1,x2,y2,outline) {
    return draw_rectangle(x1,y1,x2,y2,outline);
}

function rysuj_trojkat(x1,y1,x2,y2,x3,y3,outline) {
    return draw_triangle(x1,y1,x2,y2,x3,y3,outline);
}

function ustaw_kolor(color) {
    return draw_set_color(color);
}

function ustaw_przezroczystosc(alpha) {
    return draw_set_alpha(alpha);
}

function ustaw_czcionke(font) {
    return draw_set_font(font);
}
