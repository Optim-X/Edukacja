// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function utworz_bufor(size,type,alignment) {
    return buffer_create(size,type,alignment);
}

function zniszcz_bufor(buffer) {
    return buffer_delete(buffer);
}

function wyczysc_bufor(buffer) {
    return buffer_clear(buffer);
}

function zapisz_bufor(buffer,type,data) {
    return buffer_write(buffer,type,data);
}

function odczytaj_bufor(buffer,type) {
    return buffer_read(buffer,type);
}

function rozmiar_bufora(buffer) {
    return buffer_get_size(buffer);
}

function pozycja_bufora(buffer) {
    return buffer_tell(buffer);
}

function ustaw_pozycje_bufora(buffer,base,offset) {
    return buffer_seek(buffer,base,offset);
}

function zapisz_plik_z_bufora(buffer,filename) {
    return buffer_save(buffer,filename);
}

function wczytaj_plik_do_bufora(filename) {
    return buffer_load(filename);
}
