// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function klawisz_wcisniety(key) {
    return keyboard_check(key);
}

function klawisz_nacisniety(key) {
    return keyboard_check_pressed(key);
}

function klawisz_puszczony(key) {
    return keyboard_check_released(key);
}

function wyczysc_klawiature() {
    return keyboard_clear();
}
