// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function dlugosc_tablicy(array) {
    return array_length(array);
}

function utworz_tablice(size,value) {
    return array_create(size,value);
}

function dodaj_do_tablicy(array,value) {
    return array_push(array,value);
}

function usun_z_konca_tablicy(array) {
    return array_pop(array);
}

function usun_z_poczatku_tablicy(array) {
    return array_shift(array);
}

function dodaj_na_poczatek_tablicy(array,value) {
    return array_unshift(array,value);
}

function kopiuj_tablice(src,index,length,dest,dest_index) {
    return array_copy(src,index,length,dest,dest_index);
}

function przeszukaj_tablice(array,value) {
    return array_contains(array,value);
}

function sortuj_tablice(array,ascending) {
    return array_sort(array,ascending);
}

function odwroc_tablice(array) {
    return array_reverse(array);
}

function mieszaj_tablice(array) {
    return array_shuffle(array);
}
