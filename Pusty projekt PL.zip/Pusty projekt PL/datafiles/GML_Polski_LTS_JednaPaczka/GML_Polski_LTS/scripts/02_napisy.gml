// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function napis(v) {
    return string(v);
}

function dlugosc_napisu(str) {
    return string_length(str);
}

function pozycja_napisu(substr,str) {
    return string_pos(substr,str);
}

function fragment_napisu(str,index,count) {
    return string_copy(str,index,count);
}

function usun_napis(str,index,count) {
    return string_delete(str,index,count);
}

function wstaw_napis(substr,index,str) {
    return string_insert(substr,index,str);
}

function zamien_napis(str,substr,newstr) {
    return string_replace(str,substr,newstr);
}

function zamien_wszystkie(str,substr,newstr) {
    return string_replace_all(str,substr,newstr);
}

function male_litery(str) {
    return string_lower(str);
}

function wielkie_litery(str) {
    return string_upper(str);
}

function przytnij(str) {
    return string_trim(str);
}

function powtorz_napis(str,count) {
    return string_repeat(str,count);
}

function znak(code) {
    return chr(code);
}

function kod_znaku(str) {
    return ord(str);
}

function podziel_napis(str,delimiter) {
    return string_split(str,delimiter);
}

function zlacz_napisy(array,delimiter) {
    return string_join(array,delimiter);
}

function zawiera_napis(str,substr) {
    return string_contains(str,substr);
}
