// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function czas_systemowy() {
    return current_time();
}

function data_czas() {
    return date_current_datetime();
}

function formatuj_date(datetime) {
    return date_datetime_string(datetime);
}

function zamknij_gre() {
    return game_end();
}

function ustaw_fps(speed,type) {
    return game_set_speed(speed,type);
}

function pobierz_fps(type) {
    return game_get_speed(type);
}
