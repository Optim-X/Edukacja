// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function wartosc_bezwzgledna(x) {
    return abs(x);
}

function zaokraglij(x) {
    return round(x);
}

function zaokraglij_w_dol(x) {
    return floor(x);
}

function zaokraglij_w_gore(x) {
    return ceil(x);
}

function minimum(a,b) {
    return min(a,b);
}

function maksimum(a,b) {
    return max(a,b);
}

function potega(x,p) {
    return power(x,p);
}

function pierwiastek(x) {
    return sqrt(x);
}

function sinus(x) {
    return sin(x);
}

function cosinus(x) {
    return cos(x);
}

function tangens(x) {
    return tan(x);
}

function losowa(x) {
    return random(x);
}

function losowa_calkowita(x) {
    return irandom(x);
}

function losowa_zakres(a,b) {
    return random_range(a,b);
}

function losowa_calkowita_zakres(a,b) {
    return irandom_range(a,b);
}

function interpoluj(a,b,t) {
    return lerp(a,b,t);
}

function odleglosc(x1,y1,x2,y2) {
    return point_distance(x1,y1,x2,y2);
}

function kierunek(x1,y1,x2,y2) {
    return point_direction(x1,y1,x2,y2);
}
