// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function odtworz_dzwiek(sound,priority,loop) {
    return audio_play_sound(sound,priority,loop);
}

function zatrzymaj_dzwiek(sound) {
    return audio_stop_sound(sound);
}

function pauza_dzwiek(sound) {
    return audio_pause_sound(sound);
}

function wznow_dzwiek(sound) {
    return audio_resume_sound(sound);
}

function ustaw_glosnosc(sound,volume,time) {
    return audio_sound_gain(sound,volume,time);
}

function czy_audio_gotowe() {
    return audio_system_is_initialised();
}
