// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function utworz_mape() {
    return ds_map_create();
}

function usun_mape(map) {
    return ds_map_destroy(map);
}

function dodaj_do_mapy(map,key,value) {
    return ds_map_add(map,key,value);
}

function ustaw_w_mapie(map,key,value) {
    return ds_map_set(map,key,value);
}

function pobierz_z_mapy(map,key) {
    return ds_map_find_value(map,key);
}

function usun_z_mapy(map,key) {
    return ds_map_delete(map,key);
}

function rozmiar_mapy(map) {
    return ds_map_size(map);
}

function wyczysc_mape(map) {
    return ds_map_clear(map);
}

function utworz_liste() {
    return ds_list_create();
}

function usun_liste(list) {
    return ds_list_destroy(list);
}

function dodaj_do_listy(list,value) {
    return ds_list_add(list,value);
}

function usun_z_listy(list,pos) {
    return ds_list_delete(list,pos);
}

function pobierz_z_listy(list,pos) {
    return ds_list_find_value(list,pos);
}

function rozmiar_listy(list) {
    return ds_list_size(list);
}
