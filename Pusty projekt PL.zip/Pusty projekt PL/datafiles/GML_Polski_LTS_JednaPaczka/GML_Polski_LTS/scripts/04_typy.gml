// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function typ_danych(variable) {
    return typeof(variable);
}

function czy_liczba(variable) {
    return is_real(variable);
}

function czy_calkowita(variable) {
    return is_int32(variable);
}

function czy_napis(variable) {
    return is_string(variable);
}

function czy_tablica(variable) {
    return is_array(variable);
}

function czy_struct(variable) {
    return is_struct(variable);
}

function czy_undefined(variable) {
    return is_undefined(variable);
}

function czy_null(variable) {
    return is_null(variable);
}

function czy_metoda(variable) {
    return is_method(variable);
}
