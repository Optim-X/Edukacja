// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function przejdz_do_pokoju(room) {
    return room_goto(room);
}

function przejdz_do_nastepnego_pokoju() {
    return room_goto_next();
}

function przejdz_do_poprzedniego_pokoju() {
    return room_goto_previous();
}

function uruchom_pokoj_od_nowa() {
    return room_restart();
}

function czy_pokoj_istnieje(room) {
    return room_exists(room);
}

function nazwa_pokoju(room) {
    return room_get_name(room);
}
