// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function otworz_ini(fname) {
    return ini_open(fname);
}

function otworz_ini_z_napisu(str) {
    return ini_open_from_string(str);
}

function zamknij_ini() {
    return ini_close();
}

function zapisz_liczbe_ini(section,key,value) {
    return ini_write_real(section,key,value);
}

function zapisz_napis_ini(section,key,value) {
    return ini_write_string(section,key,value);
}

function czytaj_liczbe_ini(section,key,default) {
    return ini_read_real(section,key,default);
}

function czytaj_napis_ini(section,key,default) {
    return ini_read_string(section,key,default);
}

function istnieje_klucz_ini(section,key) {
    return ini_key_exists(section,key);
}

function istnieje_sekcja_ini(section) {
    return ini_section_exists(section);
}

function usun_klucz_ini(section,key) {
    return ini_key_delete(section,key);
}

function usun_sekcje_ini(section) {
    return ini_section_delete(section);
}
