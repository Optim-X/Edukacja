// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function utworz_instancje(x,y,layer,obj) {
    return instance_create_layer(x,y,layer,obj);
}

function utworz_instancje_glebokosc(x,y,depth,obj) {
    return instance_create_depth(x,y,depth,obj);
}

function zniszcz_instancje(id) {
    return instance_destroy(id);
}

function istnieje_instancja(obj) {
    return instance_exists(obj);
}

function liczba_instancji(obj) {
    return instance_number(obj);
}

function znajdz_instancje(obj,n) {
    return instance_find(obj,n);
}

function znajdz_w_miejscu(x,y,obj) {
    return instance_place(x,y,obj);
}

function instancja_w_punkcie(x,y,obj) {
    return instance_position(x,y,obj);
}
