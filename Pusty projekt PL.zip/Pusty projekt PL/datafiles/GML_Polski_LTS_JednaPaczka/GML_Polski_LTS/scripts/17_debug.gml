// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function pokaz_komunikat(message) {
    return show_debug_message(message);
}

function blad(message,abort) {
    return show_error(message,abort);
}
