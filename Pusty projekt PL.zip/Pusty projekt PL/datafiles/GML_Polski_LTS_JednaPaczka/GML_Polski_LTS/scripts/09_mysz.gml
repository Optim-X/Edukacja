// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function mysz_wcisnieta(button) {
    return mouse_check_button(button);
}

function mysz_nacisnieta(button) {
    return mouse_check_button_pressed(button);
}

function mysz_puszczona(button) {
    return mouse_check_button_released(button);
}

function ustaw_pozycje_myszy(x,y) {
    return mouse_set_position(x,y);
}

function ustaw_kursor(cursor) {
    return mouse_set_cursor(cursor);
}
