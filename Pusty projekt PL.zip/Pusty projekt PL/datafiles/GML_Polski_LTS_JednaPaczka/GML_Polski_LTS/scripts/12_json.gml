// GML Polski - aliasy dla GameMaker LTS
// Oryginalne funkcje GameMaker pozostaja dostepne.

function zamien_na_json(value) {
    return json_stringify(value);
}

function odczytaj_json(str) {
    return json_parse(str);
}

function koduj_json(value) {
    return json_encode(value);
}

function dekoduj_json(str) {
    return json_decode(str);
}
