GML Polski – GameMaker LTS

Pakiet zawiera polskie aliasy funkcji GML. Oryginalne funkcje GameMaker pozostają bez zmian.
Nazwy bez polskich znaków są celowe dla kompatybilności.

Przykłady:
    pokaz_komunikat("Witaj!");
    x = zaokraglij(x);
    tekst = fragment_napisu("GameMaker", 1, 4);

Jest to baza startowa. Przed użyciem w dużym projekcie zaleca się sprawdzenie sygnatur z dokumentacją LTS.
Oficjalna dokumentacja: https://manual.gamemaker.io/lts/en/GameMaker_Language/GML_Reference/
