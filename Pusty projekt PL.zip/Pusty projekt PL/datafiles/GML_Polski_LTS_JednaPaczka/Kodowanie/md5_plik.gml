/// @function md5_plik(filename)
/// @description MD5 pliku.
/// @param {any} filename Parametry zgodne z funkcją md5_file.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// md5_plik(filename);
/// @see md5_file

function md5_plik(_filename)
{
    return md5_file(_filename);
}
