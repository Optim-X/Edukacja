/// @function crc32_bufora(buffer)
/// @description CRC32 bufora.
/// @param {any} buffer Parametry zgodne z funkcją buffer_crc32.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// crc32_bufora(buffer);
/// @see buffer_crc32

function crc32_bufora(_buffer)
{
    return buffer_crc32(_buffer);
}
