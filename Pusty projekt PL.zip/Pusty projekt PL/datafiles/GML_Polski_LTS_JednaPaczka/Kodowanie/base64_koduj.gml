/// @function base64_koduj(buffer)
/// @description Koduje Base64.
/// @param {any} buffer Parametry zgodne z funkcją base64_encode.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// base64_koduj(buffer);
/// @see base64_encode

function base64_koduj(_buffer)
{
    return base64_encode(_buffer);
}
