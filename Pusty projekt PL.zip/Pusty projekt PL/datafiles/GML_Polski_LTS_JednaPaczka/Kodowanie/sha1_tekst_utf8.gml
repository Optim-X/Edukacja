/// @function sha1_tekst_utf8(string)
/// @description SHA1 tekstu.
/// @param {any} string Parametry zgodne z funkcją sha1_string_utf8.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// sha1_tekst_utf8(string);
/// @see sha1_string_utf8

function sha1_tekst_utf8(_string)
{
    return sha1_string_utf8(_string);
}
