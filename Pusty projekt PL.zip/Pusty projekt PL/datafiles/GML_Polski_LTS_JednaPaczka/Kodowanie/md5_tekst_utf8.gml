/// @function md5_tekst_utf8(string)
/// @description MD5 tekstu.
/// @param {any} string Parametry zgodne z funkcją md5_string_utf8.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// md5_tekst_utf8(string);
/// @see md5_string_utf8

function md5_tekst_utf8(_string)
{
    return md5_string_utf8(_string);
}
