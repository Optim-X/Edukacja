/// @function sha1_plik(filename)
/// @description SHA1 pliku.
/// @param {any} filename Parametry zgodne z funkcją sha1_file.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// sha1_plik(filename);
/// @see sha1_file

function sha1_plik(_filename)
{
    return sha1_file(_filename);
}
