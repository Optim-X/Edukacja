/// @function sha1_bufora(buffer)
/// @description SHA1 bufora.
/// @param {any} buffer Parametry zgodne z funkcją buffer_sha1.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// sha1_bufora(buffer);
/// @see buffer_sha1

function sha1_bufora(_buffer)
{
    return buffer_sha1(_buffer);
}
