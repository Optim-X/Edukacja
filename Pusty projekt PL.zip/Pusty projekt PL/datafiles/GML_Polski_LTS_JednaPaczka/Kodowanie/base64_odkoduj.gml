/// @function base64_odkoduj(string)
/// @description Dekoduje Base64.
/// @param {any} string Parametry zgodne z funkcją base64_decode.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// base64_odkoduj(string);
/// @see base64_decode

function base64_odkoduj(_string)
{
    return base64_decode(_string);
}
