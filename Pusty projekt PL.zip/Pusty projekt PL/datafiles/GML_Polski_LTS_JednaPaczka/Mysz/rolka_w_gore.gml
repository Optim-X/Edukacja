/// @function rolka_w_gore()
/// @description Rolka w górę.
/// @param {any} brak Parametry zgodne z funkcją mouse_wheel_up.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rolka_w_gore();
/// @see mouse_wheel_up

function rolka_w_gore()
{
    return mouse_wheel_up();
}
