/// @function rolka_w_dol()
/// @description Rolka w dół.
/// @param {any} brak Parametry zgodne z funkcją mouse_wheel_down.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// rolka_w_dol();
/// @see mouse_wheel_down

function rolka_w_dol()
{
    return mouse_wheel_down();
}
