/// @function przycisk_myszy(button)
/// @description Sprawdza przycisk myszy.
/// @param {any} button Parametry zgodne z funkcją mouse_check_button.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// przycisk_myszy(button);
/// @see mouse_check_button

function przycisk_myszy(_button)
{
    return mouse_check_button(_button);
}
