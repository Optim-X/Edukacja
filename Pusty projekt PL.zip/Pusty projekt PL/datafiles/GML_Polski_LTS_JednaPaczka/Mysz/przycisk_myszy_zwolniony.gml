/// @function przycisk_myszy_zwolniony(button)
/// @description Sprawdza zwolnienie myszy.
/// @param {any} button Parametry zgodne z funkcją mouse_check_button_released.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// przycisk_myszy_zwolniony(button);
/// @see mouse_check_button_released

function przycisk_myszy_zwolniony(_button)
{
    return mouse_check_button_released(_button);
}
