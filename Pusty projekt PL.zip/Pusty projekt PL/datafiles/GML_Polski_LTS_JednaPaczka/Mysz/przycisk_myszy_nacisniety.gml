/// @function przycisk_myszy_nacisniety(button)
/// @description Sprawdza naciśnięcie myszy.
/// @param {any} button Parametry zgodne z funkcją mouse_check_button_pressed.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// przycisk_myszy_nacisniety(button);
/// @see mouse_check_button_pressed

function przycisk_myszy_nacisniety(_button)
{
    return mouse_check_button_pressed(_button);
}
