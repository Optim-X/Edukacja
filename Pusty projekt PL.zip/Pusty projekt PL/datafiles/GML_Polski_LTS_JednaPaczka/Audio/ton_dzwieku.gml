/// @function ton_dzwieku(sound,pitch)
/// @description Ustawia ton.
/// @param {any} sound, pitch Parametry zgodne z funkcją audio_sound_pitch.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ton_dzwieku(sound, pitch);
/// @see audio_sound_pitch

function ton_dzwieku(_sound, _pitch)
{
    return audio_sound_pitch(_sound, _pitch);
}
