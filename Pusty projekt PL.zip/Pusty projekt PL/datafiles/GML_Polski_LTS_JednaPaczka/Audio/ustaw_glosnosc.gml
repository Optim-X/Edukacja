/// @function ustaw_glosnosc(dzwiek, glosnosc, czas)
/// @description Zmienia głośność.
/// @param {any} _dzwiek, _glosnosc, _czas Parametr funkcji.
/// @returns {any} Wartość zwracana przez oryginalną funkcję, jeśli ją posiada.
/// @example
/// ustaw_glosnosc(dzwiek, glosnosc, czas);
function ustaw_glosnosc(_dzwiek, _glosnosc, _czas)
{
    audio_sound_gain(_dzwiek, _glosnosc, _czas);
}
