/// @function odtworz_dzwiek(sound,priority,loop)
/// @description Odtwarza dźwięk.
/// @param {any} sound, priority, loop Parametry zgodne z funkcją audio_play_sound.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// odtworz_dzwiek(sound, priority, loop);
/// @see audio_play_sound

function odtworz_dzwiek(_sound, _priority, _loop)
{
    return audio_play_sound(_sound, _priority, _loop);
}
