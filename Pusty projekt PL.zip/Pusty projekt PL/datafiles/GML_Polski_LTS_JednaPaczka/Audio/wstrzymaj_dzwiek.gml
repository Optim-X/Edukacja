/// @function wstrzymaj_dzwiek(sound)
/// @description Wstrzymuje dźwięk.
/// @param {any} sound Parametry zgodne z funkcją audio_pause_sound.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wstrzymaj_dzwiek(sound);
/// @see audio_pause_sound

function wstrzymaj_dzwiek(_sound)
{
    return audio_pause_sound(_sound);
}
