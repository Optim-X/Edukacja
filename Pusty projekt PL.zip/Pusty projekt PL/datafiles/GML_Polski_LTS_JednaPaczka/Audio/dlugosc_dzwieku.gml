/// @function dlugosc_dzwieku(sound)
/// @description Długość dźwięku.
/// @param {any} sound Parametry zgodne z funkcją audio_sound_length.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// dlugosc_dzwieku(sound);
/// @see audio_sound_length

function dlugosc_dzwieku(_sound)
{
    return audio_sound_length(_sound);
}
