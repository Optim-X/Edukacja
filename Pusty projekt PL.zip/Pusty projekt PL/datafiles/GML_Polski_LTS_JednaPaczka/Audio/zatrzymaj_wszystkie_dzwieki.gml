/// @function zatrzymaj_wszystkie_dzwieki()
/// @description Zatrzymuje wszystkie dźwięki.
/// @param {any} brak Parametry zgodne z funkcją audio_stop_all.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zatrzymaj_wszystkie_dzwieki();
/// @see audio_stop_all

function zatrzymaj_wszystkie_dzwieki()
{
    return audio_stop_all();
}
