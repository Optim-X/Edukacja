/// @function wznow_dzwiek(sound)
/// @description Wznawia dźwięk.
/// @param {any} sound Parametry zgodne z funkcją audio_resume_sound.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// wznow_dzwiek(sound);
/// @see audio_resume_sound

function wznow_dzwiek(_sound)
{
    return audio_resume_sound(_sound);
}
