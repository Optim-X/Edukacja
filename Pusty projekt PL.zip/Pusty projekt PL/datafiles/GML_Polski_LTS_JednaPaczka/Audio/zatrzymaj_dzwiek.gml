/// @function zatrzymaj_dzwiek(sound)
/// @description Zatrzymuje dźwięk.
/// @param {any} sound Parametry zgodne z funkcją audio_stop_sound.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// zatrzymaj_dzwiek(sound);
/// @see audio_stop_sound

function zatrzymaj_dzwiek(_sound)
{
    return audio_stop_sound(_sound);
}
