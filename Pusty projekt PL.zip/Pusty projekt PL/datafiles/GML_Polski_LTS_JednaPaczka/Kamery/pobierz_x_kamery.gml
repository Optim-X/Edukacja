/// @function pobierz_x_kamery(camera)
/// @description Pobiera X widoku.
/// @param {any} camera Parametry zgodne z funkcją camera_get_view_x.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pobierz_x_kamery(camera);
/// @see camera_get_view_x

function pobierz_x_kamery(_camera)
{
    return camera_get_view_x(_camera);
}
