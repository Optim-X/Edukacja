/// @function utworz_kamere()
/// @description Tworzy kamerę.
/// @param {any} brak Parametry zgodne z funkcją camera_create.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// utworz_kamere();
/// @see camera_create

function utworz_kamere()
{
    return camera_create();
}
