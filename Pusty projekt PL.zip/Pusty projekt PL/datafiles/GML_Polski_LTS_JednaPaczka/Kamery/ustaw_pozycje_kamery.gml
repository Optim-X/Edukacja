/// @function ustaw_pozycje_kamery(camera,x,y)
/// @description Ustawia pozycję kamery.
/// @param {any} camera, x, y Parametry zgodne z funkcją camera_set_view_pos.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_pozycje_kamery(camera, x, y);
/// @see camera_set_view_pos

function ustaw_pozycje_kamery(_camera, _x, _y)
{
    return camera_set_view_pos(_camera, _x, _y);
}
