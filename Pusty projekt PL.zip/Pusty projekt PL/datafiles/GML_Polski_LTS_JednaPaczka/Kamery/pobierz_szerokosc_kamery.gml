/// @function pobierz_szerokosc_kamery(camera)
/// @description Pobiera szerokość.
/// @param {any} camera Parametry zgodne z funkcją camera_get_view_width.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pobierz_szerokosc_kamery(camera);
/// @see camera_get_view_width

function pobierz_szerokosc_kamery(_camera)
{
    return camera_get_view_width(_camera);
}
