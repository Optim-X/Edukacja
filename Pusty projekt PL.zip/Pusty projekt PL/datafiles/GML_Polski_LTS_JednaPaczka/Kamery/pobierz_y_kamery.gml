/// @function pobierz_y_kamery(camera)
/// @description Pobiera Y widoku.
/// @param {any} camera Parametry zgodne z funkcją camera_get_view_y.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pobierz_y_kamery(camera);
/// @see camera_get_view_y

function pobierz_y_kamery(_camera)
{
    return camera_get_view_y(_camera);
}
