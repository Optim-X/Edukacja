/// @function ustaw_rozmiar_kamery(camera,w,h)
/// @description Ustawia rozmiar widoku.
/// @param {any} camera, w, h Parametry zgodne z funkcją camera_set_view_size.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// ustaw_rozmiar_kamery(camera, w, h);
/// @see camera_set_view_size

function ustaw_rozmiar_kamery(_camera, _w, _h)
{
    return camera_set_view_size(_camera, _w, _h);
}
