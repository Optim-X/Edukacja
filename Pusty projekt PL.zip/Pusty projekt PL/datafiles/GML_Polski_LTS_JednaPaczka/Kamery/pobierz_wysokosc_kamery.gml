/// @function pobierz_wysokosc_kamery(camera)
/// @description Pobiera wysokość.
/// @param {any} camera Parametry zgodne z funkcją camera_get_view_height.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// pobierz_wysokosc_kamery(camera);
/// @see camera_get_view_height

function pobierz_wysokosc_kamery(_camera)
{
    return camera_get_view_height(_camera);
}
