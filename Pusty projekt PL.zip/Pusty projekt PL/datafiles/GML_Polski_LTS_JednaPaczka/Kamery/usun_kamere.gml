/// @function usun_kamere(camera)
/// @description Usuwa kamerę.
/// @param {any} camera Parametry zgodne z funkcją camera_destroy.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// usun_kamere(camera);
/// @see camera_destroy

function usun_kamere(_camera)
{
    return camera_destroy(_camera);
}
