/// @function czy_sprite_istnieje(sprite)
/// @description Sprawdza sprite.
/// @param {any} sprite Parametry zgodne z funkcją sprite_exists.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_sprite_istnieje(sprite);
/// @see sprite_exists

function czy_sprite_istnieje(_sprite)
{
    return sprite_exists(_sprite);
}
