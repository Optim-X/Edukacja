/// @function indeks_zasobu(name)
/// @description Indeks zasobu po nazwie.
/// @param {any} name Parametry zgodne z funkcją asset_get_index.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// indeks_zasobu(name);
/// @see asset_get_index

function indeks_zasobu(_name)
{
    return asset_get_index(_name);
}
