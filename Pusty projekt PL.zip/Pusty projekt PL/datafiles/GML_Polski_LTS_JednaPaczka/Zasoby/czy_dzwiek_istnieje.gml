/// @function czy_dzwiek_istnieje(sound)
/// @description Sprawdza dźwięk.
/// @param {any} sound Parametry zgodne z funkcją sound_exists.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_dzwiek_istnieje(sound);
/// @see sound_exists

function czy_dzwiek_istnieje(_sound)
{
    return sound_exists(_sound);
}
