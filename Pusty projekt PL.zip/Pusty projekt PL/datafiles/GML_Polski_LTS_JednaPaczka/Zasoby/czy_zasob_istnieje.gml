/// @function czy_zasob_istnieje(asset)
/// @description Sprawdza zasób.
/// @param {any} asset Parametry zgodne z funkcją asset_exists.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_zasob_istnieje(asset);
/// @see asset_exists

function czy_zasob_istnieje(_asset)
{
    return asset_exists(_asset);
}
