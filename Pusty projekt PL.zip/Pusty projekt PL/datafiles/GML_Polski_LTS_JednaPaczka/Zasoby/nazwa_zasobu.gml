/// @function nazwa_zasobu(asset)
/// @description Nazwa zasobu.
/// @param {any} asset Parametry zgodne z funkcją asset_get_name.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// nazwa_zasobu(asset);
/// @see asset_get_name

function nazwa_zasobu(_asset)
{
    return asset_get_name(_asset);
}
