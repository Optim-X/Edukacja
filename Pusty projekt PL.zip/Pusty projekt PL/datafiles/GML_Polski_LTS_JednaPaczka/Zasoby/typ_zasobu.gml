/// @function typ_zasobu(asset)
/// @description Typ zasobu.
/// @param {any} asset Parametry zgodne z funkcją asset_get_type.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// typ_zasobu(asset);
/// @see asset_get_type

function typ_zasobu(_asset)
{
    return asset_get_type(_asset);
}
