{
  "$GMScript":"v1",
  "%Name":"kierunek_punktu",
  "isCompatibility":false,
  "isDnD":false,
  "name":"kierunek_punktu",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}