/// @function ile_instancji(obiekt)
/// @description Zwraca liczbę instancji obiektu.
/// @param obiekt
/// @returns true lub false albo wartość liczbową.
/// @example
/// ile_instancji(...);

function ile_instancji(_obiekt)
{
    return instance_number(_obiekt);
}
