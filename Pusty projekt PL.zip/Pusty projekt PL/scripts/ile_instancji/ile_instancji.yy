{
  "$GMScript":"v1",
  "%Name":"ile_instancji",
  "isCompatibility":false,
  "isDnD":false,
  "name":"ile_instancji",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}