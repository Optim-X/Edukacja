{
  "$GMScript":"v1",
  "%Name":"czesc_ulamkowa",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czesc_ulamkowa",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}