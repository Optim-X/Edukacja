{
  "$GMScript":"v1",
  "%Name":"ds_istnieje",
  "isCompatibility":false,
  "isDnD":false,
  "name":"ds_istnieje",
  "parent":{
    "name":"DS",
    "path":"folders/Polskie skrypty/DS.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}