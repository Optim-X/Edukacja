{
  "$GMScript":"v1",
  "%Name":"podejrzyj_bufor",
  "isCompatibility":false,
  "isDnD":false,
  "name":"podejrzyj_bufor",
  "parent":{
    "name":"Bufory",
    "path":"folders/Polskie skrypty/Bufory.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}