{
  "$GMScript":"v1",
  "%Name":"czy_pokoj_istnieje",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_pokoj_istnieje",
  "parent":{
    "name":"Pokoje",
    "path":"folders/Polskie skrypty/Pokoje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}