{
  "$GMScript":"v1",
  "%Name":"losowa",
  "isCompatibility":false,
  "isDnD":false,
  "name":"losowa",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}