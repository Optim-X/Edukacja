/// @function czy_wieksze(a, b)
/// @description Sprawdza, czy pierwsza wartość jest większa.
/// @param a, b
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_wieksze(..., ...);

function czy_wieksze(_a, _b)
{
    return _a > _b;
}
