{
  "$GMScript":"v1",
  "%Name":"czy_wieksze",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_wieksze",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}