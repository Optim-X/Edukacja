{
  "$GMScript":"v1",
  "%Name":"base64_koduj",
  "isCompatibility":false,
  "isDnD":false,
  "name":"base64_koduj",
  "parent":{
    "name":"Kodowanie",
    "path":"folders/Polskie skrypty/Kodowanie.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}