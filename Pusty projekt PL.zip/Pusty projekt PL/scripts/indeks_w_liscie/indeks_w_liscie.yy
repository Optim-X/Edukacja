{
  "$GMScript":"v1",
  "%Name":"indeks_w_liscie",
  "isCompatibility":false,
  "isDnD":false,
  "name":"indeks_w_liscie",
  "parent":{
    "name":"DS",
    "path":"folders/Polskie skrypty/DS.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}