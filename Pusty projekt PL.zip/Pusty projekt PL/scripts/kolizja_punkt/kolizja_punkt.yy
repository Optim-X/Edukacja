{
  "$GMScript":"v1",
  "%Name":"kolizja_punkt",
  "isCompatibility":false,
  "isDnD":false,
  "name":"kolizja_punkt",
  "parent":{
    "name":"Kolizje",
    "path":"folders/Polskie skrypty/Kolizje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}