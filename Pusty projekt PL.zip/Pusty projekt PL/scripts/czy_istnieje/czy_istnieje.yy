{
  "$GMScript":"v1",
  "%Name":"czy_istnieje",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_istnieje",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}