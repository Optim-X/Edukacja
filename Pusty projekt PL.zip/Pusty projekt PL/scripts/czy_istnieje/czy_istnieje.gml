/// @function czy_istnieje(instancja)
/// @description Sprawdza, czy wskazana instancja istnieje.
/// @param instancja
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_istnieje(...);

function czy_istnieje(_instancja)
{
    return instance_exists(_instancja);
}
