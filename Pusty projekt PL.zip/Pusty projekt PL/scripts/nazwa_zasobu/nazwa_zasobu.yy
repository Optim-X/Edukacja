{
  "$GMScript":"v1",
  "%Name":"nazwa_zasobu",
  "isCompatibility":false,
  "isDnD":false,
  "name":"nazwa_zasobu",
  "parent":{
    "name":"Zasoby",
    "path":"folders/Polskie skrypty/Zasoby.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}