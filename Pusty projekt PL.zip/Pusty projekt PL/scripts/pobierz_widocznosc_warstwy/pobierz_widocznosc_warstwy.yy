{
  "$GMScript":"v1",
  "%Name":"pobierz_widocznosc_warstwy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pobierz_widocznosc_warstwy",
  "parent":{
    "name":"Warstwy",
    "path":"folders/Polskie skrypty/Warstwy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}