{
  "$GMScript":"v1",
  "%Name":"instancja_w_pozycji",
  "isCompatibility":false,
  "isDnD":false,
  "name":"instancja_w_pozycji",
  "parent":{
    "name":"Kolizje",
    "path":"folders/Polskie skrypty/Kolizje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}