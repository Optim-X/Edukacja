{
  "$GMScript":"v1",
  "%Name":"komunikat_debug_rozszerzony",
  "isCompatibility":false,
  "isDnD":false,
  "name":"komunikat_debug_rozszerzony",
  "parent":{
    "name":"Debug",
    "path":"folders/Polskie skrypty/Debug.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}