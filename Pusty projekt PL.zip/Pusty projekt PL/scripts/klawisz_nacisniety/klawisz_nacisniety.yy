{
  "$GMScript":"v1",
  "%Name":"klawisz_nacisniety",
  "isCompatibility":false,
  "isDnD":false,
  "name":"klawisz_nacisniety",
  "parent":{
    "name":"Klawiatura",
    "path":"folders/Polskie skrypty/Klawiatura.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}