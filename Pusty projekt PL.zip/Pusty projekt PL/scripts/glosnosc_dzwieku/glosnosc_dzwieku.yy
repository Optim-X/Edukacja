{
  "$GMScript":"v1",
  "%Name":"glosnosc_dzwieku",
  "isCompatibility":false,
  "isDnD":false,
  "name":"glosnosc_dzwieku",
  "parent":{
    "name":"Audio",
    "path":"folders/Polskie skrypty/Audio.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}