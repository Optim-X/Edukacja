/// @function glosnosc_dzwieku(sound,gain,time)
/// @description Ustawia głośność.
/// @param {any} sound, gain, time Parametry zgodne z funkcją audio_sound_gain.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// glosnosc_dzwieku(sound, gain, time);
/// @see audio_sound_gain

function glosnosc_dzwieku(_sound, _gain, _time)
{
    return audio_sound_gain(_sound, _gain, _time);
}