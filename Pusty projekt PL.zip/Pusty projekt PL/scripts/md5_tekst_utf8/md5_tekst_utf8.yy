{
  "$GMScript":"v1",
  "%Name":"md5_tekst_utf8",
  "isCompatibility":false,
  "isDnD":false,
  "name":"md5_tekst_utf8",
  "parent":{
    "name":"Kodowanie",
    "path":"folders/Polskie skrypty/Kodowanie.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}