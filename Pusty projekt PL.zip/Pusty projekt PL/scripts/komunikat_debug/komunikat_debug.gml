function komunikat_debug(){

}