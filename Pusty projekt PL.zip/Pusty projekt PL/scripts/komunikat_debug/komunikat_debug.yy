{
  "$GMScript":"v1",
  "%Name":"komunikat_debug",
  "isCompatibility":false,
  "isDnD":false,
  "name":"komunikat_debug",
  "parent":{
    "name":"Debug",
    "path":"folders/Polskie skrypty/Debug.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}