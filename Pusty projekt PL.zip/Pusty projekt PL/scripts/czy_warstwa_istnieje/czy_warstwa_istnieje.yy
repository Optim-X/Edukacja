{
  "$GMScript":"v1",
  "%Name":"czy_warstwa_istnieje",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_warstwa_istnieje",
  "parent":{
    "name":"Warstwy",
    "path":"folders/Polskie skrypty/Warstwy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}