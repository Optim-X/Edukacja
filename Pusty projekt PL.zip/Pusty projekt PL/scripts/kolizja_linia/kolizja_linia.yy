{
  "$GMScript":"v1",
  "%Name":"kolizja_linia",
  "isCompatibility":false,
  "isDnD":false,
  "name":"kolizja_linia",
  "parent":{
    "name":"Kolizje",
    "path":"folders/Polskie skrypty/Kolizje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}