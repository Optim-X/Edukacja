{
  "$GMScript":"v1",
  "%Name":"indeks_zasobu",
  "isCompatibility":false,
  "isDnD":false,
  "name":"indeks_zasobu",
  "parent":{
    "name":"Zasoby",
    "path":"folders/Polskie skrypty/Zasoby.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}