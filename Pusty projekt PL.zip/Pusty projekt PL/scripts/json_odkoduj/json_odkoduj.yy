{
  "$GMScript":"v1",
  "%Name":"json_odkoduj",
  "isCompatibility":false,
  "isDnD":false,
  "name":"json_odkoduj",
  "parent":{
    "name":"JSON",
    "path":"folders/Polskie skrypty/JSON.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}