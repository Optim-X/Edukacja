{
  "$GMScript":"v1",
  "%Name":"nastepny_pokoj",
  "isCompatibility":false,
  "isDnD":false,
  "name":"nastepny_pokoj",
  "parent":{
    "name":"Pokoje",
    "path":"folders/Polskie skrypty/Pokoje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}