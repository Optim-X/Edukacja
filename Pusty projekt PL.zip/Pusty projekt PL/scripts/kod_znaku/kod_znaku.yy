{
  "$GMScript":"v1",
  "%Name":"kod_znaku",
  "isCompatibility":false,
  "isDnD":false,
  "name":"kod_znaku",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}