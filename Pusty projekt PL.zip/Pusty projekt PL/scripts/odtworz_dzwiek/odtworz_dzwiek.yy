{
  "$GMScript":"v1",
  "%Name":"odtworz_dzwiek",
  "isCompatibility":false,
  "isDnD":false,
  "name":"odtworz_dzwiek",
  "parent":{
    "name":"Audio",
    "path":"folders/Polskie skrypty/Audio.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}