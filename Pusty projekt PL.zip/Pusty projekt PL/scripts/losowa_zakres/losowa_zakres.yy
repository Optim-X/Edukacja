{
  "$GMScript":"v1",
  "%Name":"losowa_zakres",
  "isCompatibility":false,
  "isDnD":false,
  "name":"losowa_zakres",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}