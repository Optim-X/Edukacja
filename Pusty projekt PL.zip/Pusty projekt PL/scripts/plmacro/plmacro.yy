{
  "$GMScript":"v1",
  "%Name":"plmacro",
  "isCompatibility":false,
  "isDnD":false,
  "name":"plmacro",
  "parent":{
    "name":"Polskie skrypty",
    "path":"folders/Polskie skrypty.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}