
#macro kolor_czarny       c_black
#macro kolor_bialy        c_white
#macro kolor_czerwony     c_red
#macro kolor_zielony      c_green
#macro kolor_niebieski    c_blue
#macro kolor_zolty        c_yellow
#macro kolor_pomaranczowy c_orange
#macro kolor_srebrny      c_silver
#macro kolor_szary        c_gray
#macro kolor_fioletowy    c_purple
#macro kolor_oliwkowy     c_olive
#macro kolor_granatowy    c_navy
#macro kolor_teal         c_teal
#macro kolor_limonkowy    c_lime
#macro kolor_rozowy        c_fuchsia
#macro kolor_przezroczysty c_aqua

#macro klawisz_lewo       vk_left
#macro klawisz_prawo      vk_right
#macro klawisz_gora       vk_up
#macro klawisz_dol        vk_down

#macro klawisz_spacja     vk_space
#macro klawisz_enter      vk_enter
#macro klawisz_escape     vk_escape
#macro klawisz_backspace  vk_backspace
#macro klawisz_tab        vk_tab
#macro klawisz_shift      vk_shift
#macro klawisz_control    vk_control
#macro klawisz_alt        vk_alt

#macro klawisz_f1         vk_f1
#macro klawisz_f2         vk_f2
#macro klawisz_f3         vk_f3
#macro klawisz_f4         vk_f4
#macro klawisz_f5         vk_f5
#macro klawisz_f6         vk_f6
#macro klawisz_f7         vk_f7
#macro klawisz_f8         vk_f8
#macro klawisz_f9         vk_f9
#macro klawisz_f10        vk_f10
#macro klawisz_f11        vk_f11
#macro klawisz_f12        vk_f12

#macro jesli       if
#macro inaczej     else
#macro dopoki      while
#macro dla         for
#macro przerwij    break
#macro kontynuuj   continue
#macro zwroc       return
#macro wybierz     switch
#macro przypadek   case
#macro domyslnie   default