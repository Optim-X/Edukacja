{
  "$GMScript":"v1",
  "%Name":"pomieszaj_tablice",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pomieszaj_tablice",
  "parent":{
    "name":"Tablice",
    "path":"folders/Polskie skrypty/Tablice.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}