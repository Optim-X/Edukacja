/// @function czy_dzwiek_gra(sound)
/// @description Sprawdza odtwarzanie.
/// @param {any} sound Parametry zgodne z funkcją audio_is_playing.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// czy_dzwiek_gra(sound);
/// @see audio_is_playing

function czy_dzwiek_gra(_sound)
{
    return audio_is_playing(_sound);
}
