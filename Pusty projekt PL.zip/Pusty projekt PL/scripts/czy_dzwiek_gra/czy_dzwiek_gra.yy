{
  "$GMScript":"v1",
  "%Name":"czy_dzwiek_gra",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_dzwiek_gra",
  "parent":{
    "name":"Audio",
    "path":"folders/Polskie skrypty/Audio.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}