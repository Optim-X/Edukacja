{
  "$GMScript":"v1",
  "%Name":"json_tekst",
  "isCompatibility":false,
  "isDnD":false,
  "name":"json_tekst",
  "parent":{
    "name":"JSON",
    "path":"folders/Polskie skrypty/JSON.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}