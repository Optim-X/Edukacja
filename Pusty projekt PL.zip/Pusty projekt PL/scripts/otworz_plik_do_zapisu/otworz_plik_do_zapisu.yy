{
  "$GMScript":"v1",
  "%Name":"otworz_plik_do_zapisu",
  "isCompatibility":false,
  "isDnD":false,
  "name":"otworz_plik_do_zapisu",
  "parent":{
    "name":"Pliki",
    "path":"folders/Polskie skrypty/Pliki.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}