{
  "$GMScript":"v1",
  "%Name":"pobierz_y_kamery",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pobierz_y_kamery",
  "parent":{
    "name":"Kamery",
    "path":"folders/Polskie skrypty/Kamery.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}