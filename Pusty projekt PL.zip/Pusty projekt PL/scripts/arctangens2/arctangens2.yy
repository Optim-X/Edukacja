{
  "$GMScript":"v1",
  "%Name":"arctangens2",
  "isCompatibility":false,
  "isDnD":false,
  "name":"arctangens2",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}