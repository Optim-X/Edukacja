{
  "$GMScript":"v1",
  "%Name":"policz_wystapienia",
  "isCompatibility":false,
  "isDnD":false,
  "name":"policz_wystapienia",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}