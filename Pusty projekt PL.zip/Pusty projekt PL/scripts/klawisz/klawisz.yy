{
  "$GMScript":"v1",
  "%Name":"klawisz",
  "isCompatibility":false,
  "isDnD":false,
  "name":"klawisz",
  "parent":{
    "name":"Klawiatura",
    "path":"folders/Polskie skrypty/Klawiatura.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}