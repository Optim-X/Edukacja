{
  "$GMScript":"v1",
  "%Name":"pobierz_z_siarki",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pobierz_z_siarki",
  "parent":{
    "name":"DS",
    "path":"folders/Polskie skrypty/DS.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}