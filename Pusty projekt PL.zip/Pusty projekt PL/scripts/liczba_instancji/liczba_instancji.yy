{
  "$GMScript":"v1",
  "%Name":"liczba_instancji",
  "isCompatibility":false,
  "isDnD":false,
  "name":"liczba_instancji",
  "parent":{
    "name":"Instancje",
    "path":"folders/Polskie skrypty/Instancje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}