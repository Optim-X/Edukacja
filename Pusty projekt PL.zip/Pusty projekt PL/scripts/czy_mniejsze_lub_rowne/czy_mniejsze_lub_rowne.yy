{
  "$GMScript":"v1",
  "%Name":"czy_mniejsze_lub_rowne",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_mniejsze_lub_rowne",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}