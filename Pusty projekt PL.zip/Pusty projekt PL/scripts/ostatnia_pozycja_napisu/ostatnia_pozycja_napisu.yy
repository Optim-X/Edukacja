{
  "$GMScript":"v1",
  "%Name":"ostatnia_pozycja_napisu",
  "isCompatibility":false,
  "isDnD":false,
  "name":"ostatnia_pozycja_napisu",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}