/// @function czy_rownie(a, b)
/// @description Sprawdza, czy dwie wartości są równe.
/// @param a, b
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_rownie(..., ...);

function czy_rownie(_a, _b)
{
    return _a == _b;
}
