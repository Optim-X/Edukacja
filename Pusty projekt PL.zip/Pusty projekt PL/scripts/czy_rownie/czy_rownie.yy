{
  "$GMScript":"v1",
  "%Name":"czy_rownie",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_rownie",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}