{
  "$GMScript":"v1",
  "%Name":"ogranicz",
  "isCompatibility":false,
  "isDnD":false,
  "name":"ogranicz",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}