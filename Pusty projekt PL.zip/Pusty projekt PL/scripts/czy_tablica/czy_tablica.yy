{
  "$GMScript":"v1",
  "%Name":"czy_tablica",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_tablica",
  "parent":{
    "name":"Typy",
    "path":"folders/Polskie skrypty/Typy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}