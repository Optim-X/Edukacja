{
  "$GMScript":"v1",
  "%Name":"czy_puszczony",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_puszczony",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}