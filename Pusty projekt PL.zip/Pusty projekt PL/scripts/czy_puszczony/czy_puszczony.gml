/// @function czy_puszczony(klawisz)
/// @description Sprawdza, czy klawisz został puszczony w bieżącej klatce.
/// @param klawisz
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_puszczony(...);

function czy_puszczony(_klawisz)
{
    return keyboard_check_released(_klawisz);
}
