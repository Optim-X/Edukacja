{
  "$GMScript":"v1",
  "%Name":"pobierz_id_warstwy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pobierz_id_warstwy",
  "parent":{
    "name":"Warstwy",
    "path":"folders/Polskie skrypty/Warstwy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}