/// @function czy_mysz_puszczony(przycisk)
/// @description Sprawdza puszczenie przycisku myszy.
/// @param przycisk
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_mysz_puszczony(...);

function czy_mysz_puszczony(_przycisk)
{
    return mouse_check_button_released(_przycisk);
}
