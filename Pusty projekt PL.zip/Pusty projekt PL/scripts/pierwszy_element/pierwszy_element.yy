{
  "$GMScript":"v1",
  "%Name":"pierwszy_element",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pierwszy_element",
  "parent":{
    "name":"Tablice",
    "path":"folders/Polskie skrypty/Tablice.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}