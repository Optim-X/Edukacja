{
  "$GMScript":"v1",
  "%Name":"losowa_calkowita",
  "isCompatibility":false,
  "isDnD":false,
  "name":"losowa_calkowita",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}