{
  "$GMScript":"v1",
  "%Name":"miejsce_wolne",
  "isCompatibility":false,
  "isDnD":false,
  "name":"miejsce_wolne",
  "parent":{
    "name":"Kolizje",
    "path":"folders/Polskie skrypty/Kolizje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}