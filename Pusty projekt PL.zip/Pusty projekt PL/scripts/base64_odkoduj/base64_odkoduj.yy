{
  "$GMScript":"v1",
  "%Name":"base64_odkoduj",
  "isCompatibility":false,
  "isDnD":false,
  "name":"base64_odkoduj",
  "parent":{
    "name":"Kodowanie",
    "path":"folders/Polskie skrypty/Kodowanie.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}