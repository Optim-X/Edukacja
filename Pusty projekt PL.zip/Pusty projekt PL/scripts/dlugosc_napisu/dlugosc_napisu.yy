{
  "$GMScript":"v1",
  "%Name":"dlugosc_napisu",
  "isCompatibility":false,
  "isDnD":false,
  "name":"dlugosc_napisu",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}