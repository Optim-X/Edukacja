{
  "$GMScript":"v1",
  "%Name":"losowa_instancja",
  "isCompatibility":false,
  "isDnD":false,
  "name":"losowa_instancja",
  "parent":{
    "name":"Instancje",
    "path":"folders/Polskie skrypty/Instancje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}