/// @function crc32_bufora(buffer,przesuniecie,rozmiar)
/// @description CRC32 bufora.
/// @param {any} buffer Parametry zgodne z funkcją buffer_crc32.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// crc32_bufora(buffer,przesuniecie,rozmiar);
/// @see buffer_crc32

function crc32_bufora(_buffer,off,size)
{
    return buffer_crc32(_buffer,off,size);
}
