{
  "$GMScript":"v1",
  "%Name":"crc32_bufora",
  "isCompatibility":false,
  "isDnD":false,
  "name":"crc32_bufora",
  "parent":{
    "name":"Kodowanie",
    "path":"folders/Polskie skrypty/Kodowanie.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}