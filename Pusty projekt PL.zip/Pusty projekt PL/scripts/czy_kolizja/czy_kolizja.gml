/// @function czy_kolizja(x, y, obiekt)
/// @description Sprawdza, czy w podanym miejscu występuje kolizja.
/// @param x, y, obiekt
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_kolizja(..., ..., ...);

function czy_kolizja(_x, _y, _obiekt)
{
    return place_meeting(_x, _y, _obiekt);
}
