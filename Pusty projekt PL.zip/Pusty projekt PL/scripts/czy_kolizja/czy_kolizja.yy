{
  "$GMScript":"v1",
  "%Name":"czy_kolizja",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_kolizja",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}