{
  "$GMScript":"v1",
  "%Name":"klawisz_bezposrednio",
  "isCompatibility":false,
  "isDnD":false,
  "name":"klawisz_bezposrednio",
  "parent":{
    "name":"Klawiatura",
    "path":"folders/Polskie skrypty/Klawiatura.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}