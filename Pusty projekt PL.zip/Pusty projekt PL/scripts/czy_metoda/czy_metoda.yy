{
  "$GMScript":"v1",
  "%Name":"czy_metoda",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_metoda",
  "parent":{
    "name":"Typy",
    "path":"folders/Polskie skrypty/Typy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}