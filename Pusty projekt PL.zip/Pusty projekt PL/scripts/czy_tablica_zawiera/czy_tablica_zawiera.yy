{
  "$GMScript":"v1",
  "%Name":"czy_tablica_zawiera",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_tablica_zawiera",
  "parent":{
    "name":"Tablice",
    "path":"folders/Polskie skrypty/Tablice.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}