{
  "$GMScript":"v1",
  "%Name":"najblizsza_instancja",
  "isCompatibility":false,
  "isDnD":false,
  "name":"najblizsza_instancja",
  "parent":{
    "name":"Instancje",
    "path":"folders/Polskie skrypty/Instancje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}