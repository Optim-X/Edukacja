{
  "$GMScript":"v1",
  "%Name":"kopiuj_tablice",
  "isCompatibility":false,
  "isDnD":false,
  "name":"kopiuj_tablice",
  "parent":{
    "name":"Tablice",
    "path":"folders/Polskie skrypty/Tablice.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}