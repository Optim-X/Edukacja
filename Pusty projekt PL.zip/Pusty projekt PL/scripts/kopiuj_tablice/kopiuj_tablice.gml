/// @function kopiuj_tablice(tablica, indeks, tablica2, indeks2, length)
/// @description Kopiuje fragment.
/// @param {any} array, index, length Parametry zgodne z funkcją array_copy.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// kopiuj_tablice(tablica, indeks, tablica2, indeks2, length);
/// @see array_copy

function kopiuj_tablice(_array, _index, _length)
{
    return array_copy(_array, _index,src,src_index,_length);
}
