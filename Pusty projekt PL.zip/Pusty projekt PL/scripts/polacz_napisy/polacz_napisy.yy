{
  "$GMScript":"v1",
  "%Name":"polacz_napisy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"polacz_napisy",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}