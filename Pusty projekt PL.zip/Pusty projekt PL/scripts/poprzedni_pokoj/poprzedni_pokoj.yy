{
  "$GMScript":"v1",
  "%Name":"poprzedni_pokoj",
  "isCompatibility":false,
  "isDnD":false,
  "name":"poprzedni_pokoj",
  "parent":{
    "name":"Pokoje",
    "path":"folders/Polskie skrypty/Pokoje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}