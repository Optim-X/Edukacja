{
  "$GMScript":"v1",
  "%Name":"dlugosc_tablicy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"dlugosc_tablicy",
  "parent":{
    "name":"Tablice",
    "path":"folders/Polskie skrypty/Tablice.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}