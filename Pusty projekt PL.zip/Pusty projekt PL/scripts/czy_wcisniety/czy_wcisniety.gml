/// @function czy_wcisniety(klawisz)
/// @description Sprawdza, czy klawisz jest aktualnie wciśnięty.
/// @param klawisz
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_wcisniety(...);

function czy_wcisniety(_klawisz)
{
    return keyboard_check(_klawisz);
}
