{
  "$GMScript":"v1",
  "%Name":"czy_wcisniety",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_wcisniety",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}