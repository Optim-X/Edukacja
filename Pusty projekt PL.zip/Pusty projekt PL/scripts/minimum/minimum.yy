{
  "$GMScript":"v1",
  "%Name":"minimum",
  "isCompatibility":false,
  "isDnD":false,
  "name":"minimum",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}