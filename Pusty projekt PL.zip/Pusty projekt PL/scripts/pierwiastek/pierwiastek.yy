{
  "$GMScript":"v1",
  "%Name":"pierwiastek",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pierwiastek",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}