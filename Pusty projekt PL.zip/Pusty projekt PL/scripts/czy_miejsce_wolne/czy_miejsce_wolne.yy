{
  "$GMScript":"v1",
  "%Name":"czy_miejsce_wolne",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_miejsce_wolne",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}