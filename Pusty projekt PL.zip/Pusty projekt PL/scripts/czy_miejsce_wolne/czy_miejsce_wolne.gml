/// @function czy_miejsce_wolne(x, y)
/// @description Sprawdza, czy miejsce jest wolne od kolizji.
/// @param x, y
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_miejsce_wolne(..., ...);

function czy_miejsce_wolne(_x, _y)
{
    return place_free(_x, _y);
}
