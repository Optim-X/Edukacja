/// @function czy_mniejsze(a, b)
/// @description Sprawdza, czy pierwsza wartość jest mniejsza.
/// @param a, b
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_mniejsze(..., ...);

function czy_mniejsze(_a, _b)
{
    return _a < _b;
}
