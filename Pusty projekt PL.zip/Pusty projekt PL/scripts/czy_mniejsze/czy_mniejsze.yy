{
  "$GMScript":"v1",
  "%Name":"czy_mniejsze",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_mniejsze",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}