{
  "$GMScript":"v1",
  "%Name":"czy_liczba",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_liczba",
  "parent":{
    "name":"Typy",
    "path":"folders/Polskie skrypty/Typy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}