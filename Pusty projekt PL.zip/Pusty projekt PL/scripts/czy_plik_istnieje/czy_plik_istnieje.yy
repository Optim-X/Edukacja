{
  "$GMScript":"v1",
  "%Name":"czy_plik_istnieje",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_plik_istnieje",
  "parent":{
    "name":"Pliki",
    "path":"folders/Polskie skrypty/Pliki.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}