{
  "$GMScript":"v1",
  "%Name":"male_litery",
  "isCompatibility":false,
  "isDnD":false,
  "name":"male_litery",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}