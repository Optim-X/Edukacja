{
  "$GMScript":"v1",
  "%Name":"klawisz_zwolniony",
  "isCompatibility":false,
  "isDnD":false,
  "name":"klawisz_zwolniony",
  "parent":{
    "name":"Klawiatura",
    "path":"folders/Polskie skrypty/Klawiatura.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}