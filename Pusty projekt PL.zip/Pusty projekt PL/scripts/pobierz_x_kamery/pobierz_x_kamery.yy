{
  "$GMScript":"v1",
  "%Name":"pobierz_x_kamery",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pobierz_x_kamery",
  "parent":{
    "name":"Kamery",
    "path":"folders/Polskie skrypty/Kamery.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}