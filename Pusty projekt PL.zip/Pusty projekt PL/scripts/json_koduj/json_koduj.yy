{
  "$GMScript":"v1",
  "%Name":"json_koduj",
  "isCompatibility":false,
  "isDnD":false,
  "name":"json_koduj",
  "parent":{
    "name":"JSON",
    "path":"folders/Polskie skrypty/JSON.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}