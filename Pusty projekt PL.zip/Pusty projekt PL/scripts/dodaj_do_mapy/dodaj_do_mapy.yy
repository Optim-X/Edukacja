{
  "$GMScript":"v1",
  "%Name":"dodaj_do_mapy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"dodaj_do_mapy",
  "parent":{
    "name":"DS",
    "path":"folders/Polskie skrypty/DS.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}