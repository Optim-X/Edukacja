{
  "$GMScript":"v1",
  "%Name":"pomieszaj_liste",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pomieszaj_liste",
  "parent":{
    "name":"DS",
    "path":"folders/Polskie skrypty/DS.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}