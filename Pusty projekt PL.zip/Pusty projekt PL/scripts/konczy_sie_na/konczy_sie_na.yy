{
  "$GMScript":"v1",
  "%Name":"konczy_sie_na",
  "isCompatibility":false,
  "isDnD":false,
  "name":"konczy_sie_na",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}