{
  "$GMScript":"v1",
  "%Name":"czy_mysz_wcisnieta",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_mysz_wcisnieta",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}