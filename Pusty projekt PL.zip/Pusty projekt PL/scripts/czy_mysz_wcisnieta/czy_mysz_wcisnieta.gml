/// @function czy_mysz_wcisnieta(przycisk)
/// @description Sprawdza, czy przycisk myszy jest wciśnięty.
/// @param przycisk
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_mysz_wcisnieta(...);

function czy_mysz_wcisnieta(_przycisk)
{
    return mouse_check_button(_przycisk);
}
