{
  "$GMScript":"v1",
  "%Name":"najdalsza_instancja",
  "isCompatibility":false,
  "isDnD":false,
  "name":"najdalsza_instancja",
  "parent":{
    "name":"Instancje",
    "path":"folders/Polskie skrypty/Instancje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}