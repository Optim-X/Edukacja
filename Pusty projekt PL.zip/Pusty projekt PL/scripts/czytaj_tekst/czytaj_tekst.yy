{
  "$GMScript":"v1",
  "%Name":"czytaj_tekst",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czytaj_tekst",
  "parent":{
    "name":"Pliki",
    "path":"folders/Polskie skrypty/Pliki.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}