{
  "$GMScript":"v1",
  "%Name":"ostatni_klawisz",
  "isCompatibility":false,
  "isDnD":false,
  "name":"ostatni_klawisz",
  "parent":{
    "name":"Klawiatura",
    "path":"folders/Polskie skrypty/Klawiatura.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}