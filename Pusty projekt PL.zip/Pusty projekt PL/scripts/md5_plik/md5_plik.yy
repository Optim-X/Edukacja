{
  "$GMScript":"v1",
  "%Name":"md5_plik",
  "isCompatibility":false,
  "isDnD":false,
  "name":"md5_plik",
  "parent":{
    "name":"Kodowanie",
    "path":"folders/Polskie skrypty/Kodowanie.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}