{
  "$GMScript":"v1",
  "%Name":"json_parsuj",
  "isCompatibility":false,
  "isDnD":false,
  "name":"json_parsuj",
  "parent":{
    "name":"JSON",
    "path":"folders/Polskie skrypty/JSON.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}