{
  "$GMScript":"v1",
  "%Name":"md5_bufora",
  "isCompatibility":false,
  "isDnD":false,
  "name":"md5_bufora",
  "parent":{
    "name":"Kodowanie",
    "path":"folders/Polskie skrypty/Kodowanie.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}