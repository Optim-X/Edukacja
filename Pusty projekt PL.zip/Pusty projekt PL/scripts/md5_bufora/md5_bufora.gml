/// @function md5_bufora(buffer, przesuniecie, rozmiar)
/// @description MD5 bufora.
/// @param {any} buffer Parametry zgodne z funkcją buffer_md5.
/// @returns {any} Wartość zwracana przez oryginalną funkcję.
/// @example
/// md5_bufora(buffer);
/// @see buffer_md5

function md5_bufora(_buffer, off, size)
{
    return buffer_md5(_buffer, off,size);
}
