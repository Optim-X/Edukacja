{
  "$GMScript":"v1",
  "%Name":"czy_niezdefiniowana",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_niezdefiniowana",
  "parent":{
    "name":"Typy",
    "path":"folders/Polskie skrypty/Typy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}