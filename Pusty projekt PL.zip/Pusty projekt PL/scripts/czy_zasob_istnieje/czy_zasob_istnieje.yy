{
  "$GMScript":"v1",
  "%Name":"czy_zasob_istnieje",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_zasob_istnieje",
  "parent":{
    "name":"Zasoby",
    "path":"folders/Polskie skrypty/Zasoby.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}