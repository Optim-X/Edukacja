{
  "$GMScript":"v1",
  "%Name":"czy_klucz_w_mapie",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_klucz_w_mapie",
  "parent":{
    "name":"DS",
    "path":"folders/Polskie skrypty/DS.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}