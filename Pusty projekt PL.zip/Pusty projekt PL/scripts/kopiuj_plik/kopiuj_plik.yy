{
  "$GMScript":"v1",
  "%Name":"kopiuj_plik",
  "isCompatibility":false,
  "isDnD":false,
  "name":"kopiuj_plik",
  "parent":{
    "name":"Pliki",
    "path":"folders/Polskie skrypty/Pliki.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}