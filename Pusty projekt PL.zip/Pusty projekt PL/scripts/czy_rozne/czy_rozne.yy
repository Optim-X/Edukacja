{
  "$GMScript":"v1",
  "%Name":"czy_rozne",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_rozne",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}