/// @function czy_rozne(a, b)
/// @description Sprawdza, czy dwie wartości są różne.
/// @param a, b
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_rozne(..., ...);

function czy_rozne(_a, _b)
{
    return _a != _b;
}
