{
  "$GMScript":"v1",
  "%Name":"czy_sprite_istnieje",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_sprite_istnieje",
  "parent":{
    "name":"Zasoby",
    "path":"folders/Polskie skrypty/Zasoby.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}