{
  "$GMScript":"v1",
  "%Name":"odleglosc",
  "isCompatibility":false,
  "isDnD":false,
  "name":"odleglosc",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}