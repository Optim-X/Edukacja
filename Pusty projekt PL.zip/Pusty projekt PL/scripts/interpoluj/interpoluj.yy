{
  "$GMScript":"v1",
  "%Name":"interpoluj",
  "isCompatibility":false,
  "isDnD":false,
  "name":"interpoluj",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}