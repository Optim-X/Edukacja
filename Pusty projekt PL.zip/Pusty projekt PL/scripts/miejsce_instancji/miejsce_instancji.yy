{
  "$GMScript":"v1",
  "%Name":"miejsce_instancji",
  "isCompatibility":false,
  "isDnD":false,
  "name":"miejsce_instancji",
  "parent":{
    "name":"Kolizje",
    "path":"folders/Polskie skrypty/Kolizje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}