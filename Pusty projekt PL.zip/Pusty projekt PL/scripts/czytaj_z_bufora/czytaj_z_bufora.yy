{
  "$GMScript":"v1",
  "%Name":"czytaj_z_bufora",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czytaj_z_bufora",
  "parent":{
    "name":"Bufory",
    "path":"folders/Polskie skrypty/Bufory.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}