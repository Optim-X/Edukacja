{
  "$GMScript":"v1",
  "%Name":"instancja_istnieje",
  "isCompatibility":false,
  "isDnD":false,
  "name":"instancja_istnieje",
  "parent":{
    "name":"Instancje",
    "path":"folders/Polskie skrypty/Instancje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}