{
  "$GMScript":"v1",
  "%Name":"czy_dzwiek_istnieje",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_dzwiek_istnieje",
  "parent":{
    "name":"Zasoby",
    "path":"folders/Polskie skrypty/Zasoby.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}