{
  "$GMScript":"v1",
  "%Name":"powtorz_napis",
  "isCompatibility":false,
  "isDnD":false,
  "name":"powtorz_napis",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}