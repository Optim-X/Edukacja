{
  "$GMScript":"v1",
  "%Name":"pobierz_glebokosc_warstwy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"pobierz_glebokosc_warstwy",
  "parent":{
    "name":"Warstwy",
    "path":"folders/Polskie skrypty/Warstwy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}