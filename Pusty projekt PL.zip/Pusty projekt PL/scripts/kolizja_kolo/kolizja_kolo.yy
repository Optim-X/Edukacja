{
  "$GMScript":"v1",
  "%Name":"kolizja_kolo",
  "isCompatibility":false,
  "isDnD":false,
  "name":"kolizja_kolo",
  "parent":{
    "name":"Kolizje",
    "path":"folders/Polskie skrypty/Kolizje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}