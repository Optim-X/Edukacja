{
  "$GMScript":"v1",
  "%Name":"kolizja_prostokat",
  "isCompatibility":false,
  "isDnD":false,
  "name":"kolizja_prostokat",
  "parent":{
    "name":"Kolizje",
    "path":"folders/Polskie skrypty/Kolizje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}