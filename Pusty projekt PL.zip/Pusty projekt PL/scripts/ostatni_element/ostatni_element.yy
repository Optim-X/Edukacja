{
  "$GMScript":"v1",
  "%Name":"ostatni_element",
  "isCompatibility":false,
  "isDnD":false,
  "name":"ostatni_element",
  "parent":{
    "name":"Tablice",
    "path":"folders/Polskie skrypty/Tablice.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}