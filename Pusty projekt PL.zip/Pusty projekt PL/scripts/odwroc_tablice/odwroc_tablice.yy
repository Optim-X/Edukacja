{
  "$GMScript":"v1",
  "%Name":"odwroc_tablice",
  "isCompatibility":false,
  "isDnD":false,
  "name":"odwroc_tablice",
  "parent":{
    "name":"Tablice",
    "path":"folders/Polskie skrypty/Tablice.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}