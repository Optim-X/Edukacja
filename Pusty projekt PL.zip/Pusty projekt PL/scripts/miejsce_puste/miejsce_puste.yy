{
  "$GMScript":"v1",
  "%Name":"miejsce_puste",
  "isCompatibility":false,
  "isDnD":false,
  "name":"miejsce_puste",
  "parent":{
    "name":"Kolizje",
    "path":"folders/Polskie skrypty/Kolizje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}