{
  "$GMScript":"v1",
  "%Name":"kopiuj_napis",
  "isCompatibility":false,
  "isDnD":false,
  "name":"kopiuj_napis",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}