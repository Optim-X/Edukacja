{
  "$GMScript":"v1",
  "%Name":"dlugosc_dzwieku",
  "isCompatibility":false,
  "isDnD":false,
  "name":"dlugosc_dzwieku",
  "parent":{
    "name":"Audio",
    "path":"folders/Polskie skrypty/Audio.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}