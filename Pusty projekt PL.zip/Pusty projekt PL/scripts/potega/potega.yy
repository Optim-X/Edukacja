{
  "$GMScript":"v1",
  "%Name":"potega",
  "isCompatibility":false,
  "isDnD":false,
  "name":"potega",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}