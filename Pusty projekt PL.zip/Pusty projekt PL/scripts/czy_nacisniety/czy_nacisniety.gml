/// @function czy_nacisniety(klawisz)
/// @description Sprawdza, czy klawisz został naciśnięty w bieżącej klatce.
/// @param klawisz
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_nacisniety(...);

function czy_nacisniety(_klawisz)
{
    return keyboard_check(_klawisz);
}
