{
  "$GMScript":"v1",
  "%Name":"czy_nacisniety",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_nacisniety",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}