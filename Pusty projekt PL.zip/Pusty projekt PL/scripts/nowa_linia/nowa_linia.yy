{
  "$GMScript":"v1",
  "%Name":"nowa_linia",
  "isCompatibility":false,
  "isDnD":false,
  "name":"nowa_linia",
  "parent":{
    "name":"Pliki",
    "path":"folders/Polskie skrypty/Pliki.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}