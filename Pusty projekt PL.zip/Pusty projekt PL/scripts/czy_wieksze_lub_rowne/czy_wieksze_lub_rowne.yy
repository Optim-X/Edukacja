{
  "$GMScript":"v1",
  "%Name":"czy_wieksze_lub_rowne",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_wieksze_lub_rowne",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}