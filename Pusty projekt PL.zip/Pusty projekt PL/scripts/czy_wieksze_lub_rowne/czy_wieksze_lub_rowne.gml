/// @function czy_wieksze_lub_rowne(a, b)
/// @description Sprawdza, czy pierwsza wartość jest większa lub równa.
/// @param a, b
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_wieksze_lub_rowne(..., ...);

function czy_wieksze_lub_rowne(_a, _b)
{
    return _a >= _b;
}
