{
  "$GMScript":"v1",
  "%Name":"maksimum",
  "isCompatibility":false,
  "isDnD":false,
  "name":"maksimum",
  "parent":{
    "name":"Matematyka",
    "path":"folders/Polskie skrypty/Matematyka.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}