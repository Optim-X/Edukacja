{
  "$GMScript":"v1",
  "%Name":"nazwa_pokoju",
  "isCompatibility":false,
  "isDnD":false,
  "name":"nazwa_pokoju",
  "parent":{
    "name":"Pokoje",
    "path":"folders/Polskie skrypty/Pokoje.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}