{
  "$GMScript":"v1",
  "%Name":"dodaj_do_listy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"dodaj_do_listy",
  "parent":{
    "name":"DS",
    "path":"folders/Polskie skrypty/DS.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}