{
  "$GMScript":"v1",
  "%Name":"czy_napis_zawiera",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_napis_zawiera",
  "parent":{
    "name":"Pomocnicze",
    "path":"folders/Polskie skrypty/Pomocnicze.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}