/// @function czy_napis_zawiera(napis, szukany)
/// @description Sprawdza, czy napis zawiera fragment tekstu.
/// @param napis, szukany
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_napis_zawiera(..., ...);

function czy_napis_zawiera(_napis, _szukany)
{
    return string_pos(_szukany, _napis) > 0;
}
