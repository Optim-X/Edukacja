{
  "$GMScript":"v1",
  "%Name":"nazwa_warstwy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"nazwa_warstwy",
  "parent":{
    "name":"Warstwy",
    "path":"folders/Polskie skrypty/Warstwy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}