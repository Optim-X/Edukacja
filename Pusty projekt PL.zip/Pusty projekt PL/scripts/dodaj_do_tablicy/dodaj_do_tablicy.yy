{
  "$GMScript":"v1",
  "%Name":"dodaj_do_tablicy",
  "isCompatibility":false,
  "isDnD":false,
  "name":"dodaj_do_tablicy",
  "parent":{
    "name":"Tablice",
    "path":"folders/Polskie skrypty/Tablice.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}