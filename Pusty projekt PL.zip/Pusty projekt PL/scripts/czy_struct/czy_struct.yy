{
  "$GMScript":"v1",
  "%Name":"czy_struct",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_struct",
  "parent":{
    "name":"Typy",
    "path":"folders/Polskie skrypty/Typy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}