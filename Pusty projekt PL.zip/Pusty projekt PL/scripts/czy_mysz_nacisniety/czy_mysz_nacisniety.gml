/// @function czy_mysz_nacisniety(przycisk)
/// @description Sprawdza naciśnięcie przycisku myszy.
/// @param przycisk
/// @returns true lub false albo wartość liczbową.
/// @example
/// czy_mysz_nacisniety(...);

function czy_mysz_nacisniety(_przycisk)
{
    return mouse_check_button_pressed(_przycisk);
}
