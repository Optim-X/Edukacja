{
  "$GMScript":"v1",
  "%Name":"czy_tekst",
  "isCompatibility":false,
  "isDnD":false,
  "name":"czy_tekst",
  "parent":{
    "name":"Napisy",
    "path":"folders/Polskie skrypty/Napisy.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}